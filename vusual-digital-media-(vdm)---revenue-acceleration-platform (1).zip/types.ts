
export enum ServiceType {
  SEO = 'SEO',
  PPC = 'PPC',
  CRO = 'CRO',
  AI_STRATEGY = 'AI_STRATEGY',
  SOCIAL_MGMT = 'SOCIAL_MGMT',
  PAID_SOCIAL = 'PAID_SOCIAL',
  GHL_MANAGEMENT = 'GHL_MANAGEMENT'
}

export interface AuditResult {
  url: string;
  healthScore: number;
  revenuePotential: string;
  recommendations: string[];
  competitors: string[];
  sources?: Array<{ title?: string, uri?: string }>;
}

export interface ROIParams {
  monthlyBudget: number;
  conversionRate: number;
  averageDealValue: number;
  currentTraffic: number;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export enum PageState {
  HOME = 'HOME',
  AUDIT = 'AUDIT',
  CALCULATOR = 'CALCULATOR',
  AI_STUDIO = 'AI_STUDIO',
  VEO_GEN = 'VEO_GEN',
  SERVICE_DETAIL = 'SERVICE_DETAIL',
  PORTAL_GATEWAY = 'PORTAL_GATEWAY',
  CLIENT_PORTAL = 'CLIENT_PORTAL',
  AGENCY_PORTAL = 'AGENCY_PORTAL'
}

export type AgencyRole = 'ADMIN' | 'EDITOR' | 'BILLING' | 'VIEWER';

export interface AgencyMember {
  id: string;
  name: string;
  email: string;
  role: AgencyRole;
  joinedAt: string;
}

export interface Client {
  id: string;
  name: string;
  domain: string;
  arr: string;
  status: 'Active' | 'Scaling' | 'Authoritative' | 'Audit Phase' | 'Terminated';
  growth: string;
  owner: string;
  billingStatus: 'Paid' | 'Pending' | 'Overdue';
  agreementStatus: 'Active' | 'Pending Signature' | 'Expired';
  activeServices: ServiceType[];
  agreementUrl?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'CLIENT' | 'AGENCY';
  agencyRole?: AgencyRole;
  token: string;
}

export interface MethodologyStep {
  step: number;
  name: string;
  desc: string;
}

export interface ServiceData {
  id: string;
  name: string;
  category: string;
  heroHeadline: string;
  heroSubheadline: string;
  painPoints: Array<{ title: string; desc: string }>;
  pricingTier: Array<{ name: string; price: string; features: string[] }>;
  techProof: { toolName: string; desc: string; stats: string[] };
  faqs: Array<{ q: string; a: string }>;
  methodology?: MethodologyStep[];
}
