import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyBycQudhY9bwVtLwHH1Ljb8hcp6XgiqfDE",
  authDomain: "vusual-1446e.firebaseapp.com",
  projectId: "vusual-1446e",
  storageBucket: "vusual-1446e.firebasestorage.app",
  messagingSenderId: "150547964141",
  appId: "1:150547964141:web:a7e280c5c457906f73ece4",
  measurementId: "G-6LN8YPSCE5"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Safe Analytics initialization using isSupported() to prevent "Component not registered" errors
export let analytics: any = null;

if (typeof window !== 'undefined') {
  isSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  }).catch((err) => {
    console.warn("Firebase Analytics initialization skipped:", err);
  });
}
