
import { Client, AgencyMember, ServiceType } from '../types';

const CLIENTS_KEY = 'vdm_db_clients';
const TEAM_KEY = 'vdm_db_team';

const INITIAL_CLIENTS: Client[] = [
  { id: 'cl_001', name: 'Enterprise Alpha', domain: 'alpha.io', arr: '$2,400,000', status: 'Active', growth: '+12%', owner: 'Chief Strategist', billingStatus: 'Paid', agreementStatus: 'Active', activeServices: [ServiceType.SEO, ServiceType.AI_STRATEGY] },
  { id: 'cl_002', name: 'LuxuryFlow Retail', domain: 'luxuryflow.com', arr: '$1,100,000', status: 'Scaling', growth: '+24%', owner: 'Marcus Growth', billingStatus: 'Pending', agreementStatus: 'Pending Signature', activeServices: [ServiceType.PPC, ServiceType.CRO] },
  { id: 'cl_003', name: 'CloudScale SaaS', domain: 'cloudscale.tech', arr: '$4,800,000', status: 'Authoritative', growth: '+5%', owner: 'Chief Strategist', billingStatus: 'Paid', agreementStatus: 'Active', activeServices: [ServiceType.SEO, ServiceType.PPC, ServiceType.AI_STRATEGY] },
  { id: 'cl_004', name: 'HealthGrid Systems', domain: 'healthgrid.com', arr: '$900,000', status: 'Audit Phase', growth: '--', owner: 'Elena Finance', billingStatus: 'Pending', agreementStatus: 'Expired', activeServices: [ServiceType.SEO] },
];

const INITIAL_TEAM: AgencyMember[] = [
  { id: 'mem_001', name: 'Chief Strategist', email: 'strategist@vusualdm.com', role: 'ADMIN', joinedAt: '2023-01-15' },
  { id: 'mem_002', name: 'Marcus Growth', email: 'marcus@vusualdm.com', role: 'EDITOR', joinedAt: '2023-05-20' },
  { id: 'mem_003', name: 'Elena Finance', email: 'elena@vusualdm.com', role: 'BILLING', joinedAt: '2023-08-10' },
  { id: 'mem_004', name: 'Junior Analyst', email: 'junior@vusualdm.com', role: 'VIEWER', joinedAt: '2024-02-01' },
];

export const db = {
  getClients: (): Client[] => {
    const data = localStorage.getItem(CLIENTS_KEY);
    if (!data) {
      localStorage.setItem(CLIENTS_KEY, JSON.stringify(INITIAL_CLIENTS));
      return INITIAL_CLIENTS;
    }
    return JSON.parse(data);
  },
  getClientById: (id: string): Client | undefined => {
    return db.getClients().find(c => c.id === id);
  },
  saveClient: (client: Client) => {
    const clients = db.getClients();
    const index = clients.findIndex(c => c.id === client.id);
    if (index > -1) clients[index] = client;
    else clients.push(client);
    localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
  },
  deleteClient: (id: string) => {
    const clients = db.getClients().filter(c => c.id !== id);
    localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
  },
  getTeam: (): AgencyMember[] => {
    const data = localStorage.getItem(TEAM_KEY);
    if (!data) {
      localStorage.setItem(TEAM_KEY, JSON.stringify(INITIAL_TEAM));
      return INITIAL_TEAM;
    }
    return JSON.parse(data);
  },
  saveMember: (member: AgencyMember) => {
    const team = db.getTeam();
    const index = team.findIndex(m => m.id === member.id);
    if (index > -1) team[index] = member;
    else team.push(member);
    localStorage.setItem(TEAM_KEY, JSON.stringify(team));
  },
  deleteMember: (id: string) => {
    const team = db.getTeam().filter(m => m.id !== id);
    localStorage.setItem(TEAM_KEY, JSON.stringify(team));
  }
};
