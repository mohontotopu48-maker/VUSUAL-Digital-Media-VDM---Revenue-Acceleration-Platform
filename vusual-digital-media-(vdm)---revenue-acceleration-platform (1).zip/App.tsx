
import React, { useState, useEffect } from 'react';
import { PageState, User } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AuditTool from './components/AuditTool';
import ROICalculator from './components/ROICalculator';
import LiveConsultant from './components/LiveConsultant';
import AIStudio from './components/AIStudio';
import ServiceDetail from './components/ServiceDetail';
import ClientPortal from './components/ClientPortal';
import AgencyPortal from './components/AgencyPortal';
import PortalGateway from './components/PortalGateway';
import AgencyLogin from './components/AgencyLogin';
import ClientLogin from './components/ClientLogin';
import Footer from './components/Footer';
import FloatingChat from './components/FloatingChat';
import { logEvent } from 'firebase/analytics';
import { analytics } from './services/firebase';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageState>(PageState.HOME);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [showConsultant, setShowConsultant] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('vdm_session');
    if (savedUser) {
      const parsed = JSON.parse(savedUser);
      setUser(parsed);
    }

    const handleGlobalNav = (e: any) => {
       if (e.detail === 'AUDIT') handleHomeNavigate(PageState.AUDIT);
       if (e.detail === 'CALCULATOR') handleHomeNavigate(PageState.CALCULATOR);
    };
    window.addEventListener('vdm_navigate', handleGlobalNav);
    return () => window.removeEventListener('vdm_navigate', handleGlobalNav);
  }, []);

  const trackEvent = (name: string, params: any = {}) => {
    // Standardized Tracking Bridge for Database Analytics
    const enrichedParams = {
      ...params,
      user_id: user?.id || 'anonymous',
      timestamp: new Date().toISOString(),
      session_id: window.crypto.randomUUID ? window.crypto.randomUUID() : Math.random().toString(36)
    };

    // 1. Firebase Analytics
    if (analytics) logEvent(analytics, name, enrichedParams);
    
    // 2. Google Analytics 4 (gtag)
    if ((window as any).gtag) {
      (window as any).gtag('event', name, enrichedParams);
    }
    
    // 3. Meta Pixel (fbq) - Map VDM events to Meta standard events
    if ((window as any).fbq) {
      let metaEvent = name;
      if (name === 'Lead_Generated') metaEvent = 'Lead';
      if (name === 'ViewContent') metaEvent = 'ViewContent';
      if (name === 'Contact_Initiated') metaEvent = 'Contact';
      
      (window as any).fbq('track', metaEvent, enrichedParams);
    }
    
    // 4. Global Data Layer (for GTM/DB ingestion)
    (window as any).dataLayer?.push({
      event: name,
      ...enrichedParams
    });
  };

  const handleNavigateToService = (serviceId: string) => {
    trackEvent('ViewContent', { 
      content_name: `Service: ${serviceId}`, 
      content_category: 'Services',
      content_ids: [serviceId]
    });
    setSelectedService(serviceId);
    setCurrentPage(PageState.SERVICE_DETAIL);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleHomeNavigate = (page: PageState) => {
    trackEvent('Navigation_Triggered', { target: page });
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLoginSuccess = (userData: User) => {
    trackEvent('CompleteRegistration', { content_name: userData.role });
    setUser(userData);
    localStorage.setItem('vdm_session', JSON.stringify(userData));
    if (userData.role === 'AGENCY') setCurrentPage(PageState.AGENCY_PORTAL);
    else setCurrentPage(PageState.CLIENT_PORTAL);
  };

  const handleLogout = () => {
    trackEvent('Logout_Triggered');
    setUser(null);
    localStorage.removeItem('vdm_session');
    setCurrentPage(PageState.HOME);
  };

  const renderContent = () => {
    switch (currentPage) {
      case PageState.HOME:
        return (
          <>
            <Hero onStartAudit={() => handleHomeNavigate(PageState.AUDIT)} />
            <SectionDivider />
            <FeatureGrid onNavigateToService={handleNavigateToService} />
            <TrustWall />
            <RevenueAccelerationSection />
          </>
        );
      case PageState.AUDIT:
        return <AuditTool onComplete={() => trackEvent('Lead_Generated', { content_category: 'Audit_Tool' })} />;
      case PageState.CALCULATOR:
        return <ROICalculator />;
      case PageState.AI_STUDIO:
        return <AIStudio />;
      case PageState.SERVICE_DETAIL:
        return (
          <ServiceDetail 
            serviceId={selectedService || 'national-seo'} 
            onGetAudit={() => handleHomeNavigate(PageState.AUDIT)}
            onViewPricing={() => {
              const el = document.getElementById('pricing');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        );
      case PageState.PORTAL_GATEWAY:
        return <PortalGateway 
                  onSelectClient={() => handleHomeNavigate(PageState.CLIENT_PORTAL)} 
                  onSelectAgency={() => handleHomeNavigate(PageState.AGENCY_PORTAL)} 
                />;
      case PageState.CLIENT_PORTAL:
        if (!user || user.role !== 'CLIENT') return <ClientLogin onLoginSuccess={handleLoginSuccess} />;
        return <ClientPortal user={user} onLogout={handleLogout} />;
      case PageState.AGENCY_PORTAL:
        if (!user || user.role !== 'AGENCY') return <AgencyLogin onLoginSuccess={handleLoginSuccess} />;
        return <AgencyPortal user={user} onLoginSuccess={handleLoginSuccess} onLogout={handleLogout} />;
      default:
        return <Hero onStartAudit={() => handleHomeNavigate(PageState.AUDIT)} />;
    }
  };

  const isPortalView = [PageState.CLIENT_PORTAL, PageState.AGENCY_PORTAL, PageState.PORTAL_GATEWAY].includes(currentPage);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#88ff00] selection:text-black">
      <div className="fixed inset-0 bg-grid opacity-20 pointer-events-none" />
      <Navbar 
        onNavigate={handleHomeNavigate} 
        onNavigateToService={handleNavigateToService}
        currentPage={currentPage} 
        user={user}
        onLogout={handleLogout}
      />
      <main className={`relative ${isPortalView ? '' : 'pt-20'}`}>{renderContent()}</main>
      {!isPortalView && <Footer />}
      {currentPage !== PageState.AUDIT && !isPortalView && (
        <button 
          onClick={() => {
            trackEvent('Contact_Initiated', { method: 'Voice_Consultant' });
            setShowConsultant(!showConsultant);
          }}
          className="fixed bottom-24 right-8 z-50 p-5 rounded-full neon-gradient shadow-[0_0_30px_rgba(157,0,255,0.4)] hover:scale-110 transition-transform flex items-center justify-center group"
          title="Neural Strategy Uplink"
        >
          <svg className="w-6 h-6 text-black group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
        </button>
      )}
      {!isPortalView && <FloatingChat />}
      {showConsultant && <LiveConsultant onClose={() => setShowConsultant(false)} />}
    </div>
  );
};

const SectionDivider: React.FC = () => <div className="h-px w-full bg-gradient-to-r from-transparent via-white/10 to-transparent" />;

const FeatureGrid: React.FC<{ onNavigateToService: (id: string) => void }> = ({ onNavigateToService }) => (
  <section className="py-32 px-6 max-w-7xl mx-auto">
    <div className="text-center mb-24">
      <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#88ff00] mb-4">The VDM Advantage</h4>
      <h2 className="text-5xl md:text-7xl font-black uppercase tracking-tighter leading-[1.05]">
        Monolithic <span className="neon-text">Growth</span> Systems.
      </h2>
    </div>
    <div className="grid md:grid-cols-3 gap-10">
      {[
        { id: 'national-seo', title: "Enterprise SEO", icon: "🌐", desc: "Dominating national search volumes through high-fidelity content clusters and server-side optimization." },
        { id: 'google-ads', title: "Algorithmic PPC", icon: "🎯", desc: "Precision media buying that eliminates waste and prioritizes bottom-line ROAS at global scale." },
        { id: 'ghl-management', title: "Nexus CRM", icon: "⚡", desc: "Engineering high-fidelity GHL automation ecosystems that convert leads into revenue at scale." }
      ].map((f) => (
        <div 
          key={f.id} 
          onClick={() => onNavigateToService(f.id)}
          className="glass-panel p-12 rounded-[40px] border border-white/5 hover:border-white/20 transition-all cursor-pointer group hover:-translate-y-3 duration-500 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity text-6xl">{f.icon}</div>
          <div className="text-4xl mb-8">{f.icon}</div>
          <h3 className="text-2xl font-black mb-4 uppercase tracking-tight">{f.title}</h3>
          <p className="text-gray-500 text-sm leading-relaxed mb-10">{f.desc}</p>
          <div className="text-[10px] font-black uppercase tracking-widest text-[#88ff00] group-hover:translate-x-2 transition-transform">Enter Channel Protocol →</div>
        </div>
      ))}
    </div>
  </section>
);

const TrustWall: React.FC = () => (
  <section className="py-24 bg-white/[0.02] border-y border-white/5">
    <div className="max-w-7xl mx-auto px-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-12 grayscale opacity-40 hover:grayscale-0 hover:opacity-100 transition-all duration-1000">
        <div className="text-center md:text-left">
           <h4 className="text-[10px] font-black text-gray-600 uppercase tracking-[0.4em] mb-4">Trusted by Market Leaders</h4>
           <div className="flex flex-wrap justify-center md:justify-start gap-12 items-center">
             <div className="text-xl font-black text-white/40 tracking-tighter">GLOBAL DYNAMICS</div>
             <div className="text-xl font-black text-white/40 tracking-tighter">HEALTHFLOW</div>
             <div className="text-xl font-black text-white/40 tracking-tighter">PRESTIGE RETAIL</div>
             <div className="text-xl font-black text-white/40 tracking-tighter">NEURAL SYSTEMS</div>
           </div>
        </div>
        <div className="h-20 w-px bg-white/10 hidden md:block" />
        <div className="text-center md:text-right">
           <div className="text-4xl font-black text-[#88ff00] mb-1">$50M+</div>
           <div className="text-[10px] font-black uppercase tracking-widest text-gray-500">Revenue Attributed (YTD)</div>
        </div>
      </div>
    </div>
  </section>
);

const RevenueAccelerationSection: React.FC = () => (
  <section className="py-32 px-6 max-w-7xl mx-auto">
    <div className="glass-panel rounded-[80px] p-12 md:p-24 relative overflow-hidden border-white/10 group">
      <div className="absolute inset-0 bg-gradient-to-br from-[#88ff00]/5 to-[#9d00ff]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
      <div className="relative z-10 grid lg:grid-cols-2 gap-20 items-center">
        <div>
          <h2 className="text-5xl md:text-7xl font-black mb-10 leading-[1.05] tracking-tighter uppercase">
            Stop Guessing. <br />
            Start <span className="neon-text">Scaling.</span>
          </h2>
          <p className="text-xl text-gray-400 mb-12 leading-relaxed">
            Our technology stack eliminates marketing budget waste through neural automation. We don't just find traffic; we harvest high-intent revenue.
          </p>
          <div className="grid grid-cols-2 gap-8">
             {[
               { label: "Predictive Analytics", icon: "📊" },
               { label: "Dynamic Bidding", icon: "⚡" },
               { label: "Content Velocity", icon: "🚀" },
               { label: "Asset Synthesis", icon: "🎨" },
             ].map((item, i) => (
               <div key={i} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-lg">{item.icon}</div>
                  <span className="text-xs font-bold uppercase tracking-widest text-gray-300">{item.label}</span>
               </div>
             ))}
          </div>
        </div>
        <div className="relative" id="audit-section">
           <div className="glass-panel rounded-[40px] p-8 border border-white/20 shadow-2xl transition-all duration-700 hover:scale-[1.02] bg-black/40 backdrop-blur-3xl">
              <div className="flex justify-between items-center mb-8">
                 <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500/30" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500/30" />
                    <div className="w-3 h-3 rounded-full bg-green-500/30" />
                 </div>
                 <span className="text-[10px] font-black uppercase tracking-widest text-[#88ff00] animate-pulse">Live Revenue Node</span>
              </div>
              <div className="space-y-6">
                 {[78, 92, 84].map((p, i) => (
                   <div key={i} className="space-y-2">
                      <div className="flex justify-between text-[10px] font-black uppercase text-gray-500">
                         <span>Alpha Channel-{i+1}</span>
                         <span>{p}% Match</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                         <div className="h-full bg-gradient-to-r from-[#88ff00] to-[#9d00ff]" style={{ width: `${p}%` }} />
                      </div>
                   </div>
                 ))}
              </div>
              <div className="mt-12 p-8 bg-white/5 rounded-3xl border border-white/5">
                 <div className="text-4xl font-black text-white mb-2">$1,248,390</div>
                 <div className="text-[10px] font-black uppercase tracking-widest text-gray-600">Total Attributed Alpha (Q4)</div>
              </div>
           </div>
        </div>
      </div>
    </div>
  </section>
);

export default App;
