
import React, { useState, useEffect, useMemo } from 'react';
import { User, Client, ServiceType, AgencyMember, AgencyRole } from '../types';
import { draftAgreement, performAudit } from '../services/geminiService';
import { db } from '../services/dbService';

interface AgencyPortalProps {
  user: User | null;
  onLoginSuccess: (user: User) => void;
  onLogout: () => void;
}

const ROLE_METADATA: Record<AgencyRole, { level: number; label: string; color: string; desc: string }> = {
  ADMIN: { level: 4, label: 'Master Command', color: '#9d00ff', desc: 'Full operational control.' },
  EDITOR: { level: 3, label: 'Operational Lead', color: '#88ff00', desc: 'Management of assets.' },
  BILLING: { level: 2, label: 'Financial Analyst', color: '#3b82f6', desc: 'Revenue oversight.' },
  VIEWER: { level: 1, label: 'Market Intelligence', color: '#6b7280', desc: 'Read-only access.' },
};

const AgencyPortal: React.FC<AgencyPortalProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'performance' | 'roster' | 'billing' | 'agreements' | 'neural' | 'team'>('performance');
  const [clients, setClients] = useState<Client[]>([]);
  const [teamMembers, setTeamMembers] = useState<AgencyMember[]>([]);
  
  // Filtering State
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterBilling, setFilterBilling] = useState<string>('ALL');
  const [filterService, setFilterService] = useState<string>('ALL');

  // Modals & Dynamic States
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [editingMember, setEditingMember] = useState<AgencyMember | null>(null);
  const [pendingRole, setPendingRole] = useState<AgencyRole | null>(null);
  const [isConfirmingRole, setIsConfirmingRole] = useState(false);
  const [isGeneratingAgreement, setIsGeneratingAgreement] = useState(false);
  const [activeAgreementText, setActiveAgreementText] = useState<string | null>(null);
  const [neuralInsights, setNeuralInsights] = useState<any | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [newClient, setNewClient] = useState<Partial<Client>>({
    name: '', domain: '', arr: '$0', status: 'Audit Phase', growth: '0%', owner: user?.name || '',
    billingStatus: 'Pending', agreementStatus: 'Pending Signature', activeServices: [ServiceType.SEO]
  });

  const currentUserRole: AgencyRole = user?.agencyRole || 'ADMIN';

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setClients(db.getClients());
    setTeamMembers(db.getTeam());
  };

  const canManageClients = currentUserRole === 'ADMIN' || currentUserRole === 'EDITOR';
  const canViewRoster = currentUserRole === 'ADMIN' || currentUserRole === 'EDITOR' || currentUserRole === 'VIEWER';
  const canViewBilling = currentUserRole === 'ADMIN' || currentUserRole === 'BILLING';
  const canManageAgreements = currentUserRole === 'ADMIN' || currentUserRole === 'EDITOR';
  const canUseNeural = currentUserRole === 'ADMIN' || currentUserRole === 'EDITOR' || currentUserRole === 'VIEWER';
  const canManageTeam = currentUserRole === 'ADMIN';

  // Computed: Filtered Clients
  const filteredClients = useMemo(() => {
    return clients.filter(client => {
      const matchStatus = filterStatus === 'ALL' || client.status === filterStatus;
      const matchBilling = filterBilling === 'ALL' || client.billingStatus === filterBilling;
      const matchService = filterService === 'ALL' || client.activeServices.includes(filterService as ServiceType);
      return matchStatus && matchBilling && matchService;
    });
  }, [clients, filterStatus, filterBilling, filterService]);

  const clearFilters = () => {
    setFilterStatus('ALL');
    setFilterBilling('ALL');
    setFilterService('ALL');
  };

  // Handlers
  const handleAddClient = (e: React.FormEvent) => {
    e.preventDefault();
    const client: Client = { ...(newClient as Client), id: `cl_${Date.now()}` };
    db.saveClient(client);
    setIsAddingClient(false);
    refreshData();
  };

  const handleUpdateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingClient) {
      db.saveClient(editingClient);
      setEditingClient(null);
      refreshData();
    }
  };

  const handleDeleteClient = (id: string) => {
    if (window.confirm("CRITICAL: Permanent deletion of client profile?")) {
      db.deleteClient(id);
      refreshData();
    }
  };

  const handleEditMember = (member: AgencyMember) => {
    setEditingMember(member);
    setPendingRole(member.role);
  };

  const finalizeRoleShift = () => {
    if (!editingMember || !pendingRole) return;
    const updatedMember = { ...editingMember, role: pendingRole };
    db.saveMember(updatedMember);
    setIsConfirmingRole(false);
    setEditingMember(null);
    refreshData();
  };

  const runNeuralAudit = async (client: Client) => {
    setIsAnalyzing(true);
    try {
      const data = await performAudit(client.domain, "Enterprise");
      setNeuralInsights({ clientName: client.name, ...data });
      setActiveTab('neural');
    } catch (err) {
      alert("Neural analysis failed. Core overload.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleGenerateAgreementUI = async (client: Client) => {
    setIsGeneratingAgreement(true);
    try {
      const text = await draftAgreement(client.name, client.activeServices);
      setActiveAgreementText(text);
      setActiveTab('agreements');
    } catch (err) {
      alert("Agreement drafting failed.");
    } finally {
      setIsGeneratingAgreement(false);
    }
  };

  const totalARR = clients.reduce((acc, c) => acc + parseInt(c.arr.replace(/[^0-9]/g, '') || '0'), 0);

  return (
    <div className="min-h-screen bg-[#020202] text-white">
      {/* Sidebar Navigation */}
      <aside className="fixed left-0 top-0 bottom-0 w-24 bg-[#050505] border-r border-white/5 flex flex-col items-center py-10 z-50">
        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-black font-black text-lg mb-12 shadow-lg">V</div>
        <nav className="flex flex-col gap-8">
          {(['performance', 'roster', 'billing', 'agreements', 'neural', 'team'] as const).map((tab) => {
            const hasAccess = 
              (tab === 'roster' && canViewRoster) ||
              (tab === 'billing' && canViewBilling) ||
              (tab === 'agreements' && canManageAgreements) ||
              (tab === 'neural' && canUseNeural) ||
              (tab === 'team' && canManageTeam) ||
              (tab === 'performance');
            if (!hasAccess) return null;

            return (
              <button key={tab} onClick={() => setActiveTab(tab)}
                className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${activeTab === tab ? 'bg-[#9d00ff] text-white shadow-[0_0_20px_rgba(157,0,255,0.4)]' : 'text-gray-600 hover:text-white hover:bg-white/5'}`}
              >
                {tab === 'performance' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>}
                {tab === 'roster' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1" /></svg>}
                {tab === 'billing' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2" /></svg>}
                {tab === 'agreements' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5" /></svg>}
                {tab === 'neural' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1" /></svg>}
                {tab === 'team' && <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857" /></svg>}
              </button>
            );
          })}
        </nav>
        <button onClick={onLogout} className="mt-auto p-4 text-red-500 hover:scale-110 transition-transform"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M17 16l4-4m4 4H7" /></svg></button>
      </aside>

      <main className="pl-32 pr-12 py-12 max-w-7xl mx-auto w-full">
        <header className="flex justify-between items-end mb-16">
          <div>
            <div className="flex items-center gap-2 mb-2"><span className="text-[10px] font-black uppercase tracking-[0.4em] text-[#9d00ff]">Enterprise Hub</span><div className="w-1.5 h-1.5 rounded-full bg-[#88ff00] animate-pulse shadow-[0_0_10px_#88ff00]" /></div>
            <h1 className="text-4xl font-black uppercase tracking-tighter">Command <span className="text-[#9d00ff]">Center</span></h1>
          </div>
          <div className="text-right">
             <div className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-1">Authenticated Strategist</div>
             <div className="text-2xl font-black text-[#88ff00]">{user?.name}</div>
          </div>
        </header>

        {activeTab === 'performance' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 animate-in fade-in duration-700">
             {[
               { label: 'System Revenue (ARR)', val: `$${(totalARR / 1000000).toFixed(1)}M`, color: '#88ff00' },
               { label: 'Active Channels', val: clients.length.toString(), color: '#9d00ff' },
               { label: 'Retention Coefficient', val: '94.2%', color: '#00ccff' },
               { label: 'Neural Core Latency', val: '14ms', color: '#ff0055' },
             ].map((stat, i) => (
               <div key={i} className="glass-panel p-8 rounded-3xl border border-white/5 hover:border-white/10 transition-all">
                  <div className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-4">{stat.label}</div>
                  <div className="text-4xl font-black" style={{ color: stat.color }}>{stat.val}</div>
               </div>
             ))}
          </div>
        )}

        {activeTab === 'roster' && (
           <div className="space-y-10 animate-in fade-in duration-500">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black uppercase tracking-tight">Enterprise Roster</h3>
                {canManageClients && (
                  <button onClick={() => setIsAddingClient(true)} className="px-6 py-3 rounded-xl bg-white text-black text-[10px] font-black uppercase tracking-widest hover:bg-[#88ff00] transition-colors shadow-lg shadow-white/5">Establish New Profile</button>
                )}
             </div>

             {/* Filtering Interface */}
             <div className="glass-panel p-8 rounded-[32px] border border-white/5 space-y-6">
                <div className="flex items-center justify-between">
                   <span className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400">Filtering Engine</span>
                   <button onClick={clearFilters} className="text-[9px] font-black uppercase text-[#ff0055] hover:underline">Reset Protocols</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Status Protocol</label>
                    <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs font-bold focus:border-[#88ff00] transition-colors appearance-none cursor-pointer">
                        <option value="ALL">All Statuses</option>
                        <option value="Active">Active</option>
                        <option value="Scaling">Scaling</option>
                        <option value="Authoritative">Authoritative</option>
                        <option value="Audit Phase">Audit Phase</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Billing Tier</label>
                    <select value={filterBilling} onChange={(e) => setFilterBilling(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs font-bold focus:border-[#88ff00] transition-colors appearance-none cursor-pointer">
                        <option value="ALL">All Tiers</option>
                        <option value="Paid">Paid (Priority)</option>
                        <option value="Pending">Pending / Delinquent</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-black uppercase tracking-widest text-gray-600">Operational Focus</label>
                    <select value={filterService} onChange={(e) => setFilterService(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs font-bold focus:border-[#88ff00] transition-colors appearance-none cursor-pointer">
                        <option value="ALL">All Services</option>
                        {Object.values(ServiceType).map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                </div>
             </div>

             <div className="space-y-4">
               {filteredClients.length > 0 ? filteredClients.map((client) => (
                 <div key={client.id} className="glass-panel p-8 rounded-3xl border border-white/5 flex items-center justify-between group hover:bg-white/[0.02] transition-all">
                    <div className="flex gap-12 items-center">
                       <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center font-black text-gray-500 group-hover:bg-[#9d00ff] group-hover:text-white transition-all text-xl">{client.name.charAt(0)}</div>
                       <div>
                          <div className="text-sm font-black uppercase tracking-tight">{client.name}</div>
                          <div className="text-[10px] font-bold text-gray-600 uppercase mt-1 tracking-widest">{client.domain}</div>
                       </div>
                    </div>
                    <div className="flex gap-6 items-center">
                       <div className="text-right hidden md:block">
                          <div className="text-xs font-black">{client.arr} ARR</div>
                          <div className="flex gap-2 justify-end mt-1">
                             <span className="text-[8px] font-black text-[#88ff00] uppercase tracking-widest">{client.status}</span>
                             <span className="text-[8px] font-black text-gray-600">/</span>
                             <span className="text-[8px] font-black text-blue-400 uppercase tracking-widest">{client.billingStatus}</span>
                          </div>
                       </div>
                       <div className="flex gap-2">
                          {canManageClients && (
                            <>
                              <button onClick={() => setEditingClient(client)} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-all"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg></button>
                              <button onClick={() => runNeuralAudit(client)} className="p-3 rounded-xl bg-white/5 hover:bg-[#9d00ff]/20 text-gray-400 hover:text-[#9d00ff] transition-all"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1" /></svg></button>
                              <button onClick={() => handleGenerateAgreementUI(client)} className="p-3 rounded-xl bg-white/5 hover:bg-[#88ff00]/20 text-gray-400 hover:text-[#88ff00] transition-all"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5" /></svg></button>
                              <button onClick={() => handleDeleteClient(client.id)} className="p-3 rounded-xl bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-500 transition-all"><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862" /></svg></button>
                            </>
                          )}
                       </div>
                    </div>
                 </div>
               )) : (
                 <div className="text-center py-20 glass-panel rounded-3xl opacity-40">
                    <p className="text-sm font-black uppercase tracking-[0.5em]">Zero matching operational nodes</p>
                 </div>
               )}
             </div>
           </div>
        )}

        {activeTab === 'billing' && canViewBilling && (
          <div className="animate-in fade-in duration-500">
             <h3 className="text-xl font-black uppercase tracking-tight mb-8">Revenue Ledgers</h3>
             <div className="overflow-x-auto glass-panel rounded-3xl border border-white/5">
                <table className="w-full text-left">
                   <thead className="bg-white/5 text-[10px] font-black uppercase tracking-widest text-gray-500">
                      <tr>
                        <th className="px-8 py-6">Client Entity</th>
                        <th className="px-8 py-6">ARR Target</th>
                        <th className="px-8 py-6">Status</th>
                        <th className="px-8 py-6">Agreement</th>
                        <th className="px-8 py-6 text-right">Ledger</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y divide-white/5">
                      {clients.map(client => (
                        <tr key={client.id} className="hover:bg-white/[0.02] transition-colors group">
                           <td className="px-8 py-6"><span className="text-sm font-black text-white group-hover:text-[#88ff00] transition-colors">{client.name}</span></td>
                           <td className="px-8 py-6 text-xs font-bold text-gray-400">{client.arr}</td>
                           <td className="px-8 py-6">
                              <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-tighter ${client.billingStatus === 'Paid' ? 'bg-[#88ff00]/10 text-[#88ff00]' : 'bg-red-500/10 text-red-500'}`}>
                                 {client.billingStatus}
                              </span>
                           </td>
                           <td className="px-8 py-6 text-[10px] font-black text-gray-600 uppercase">{client.agreementStatus}</td>
                           <td className="px-8 py-6 text-right">
                              <button className="text-[10px] font-black uppercase tracking-widest text-[#9d00ff] hover:text-white transition-colors">VIEW INVOICE →</button>
                           </td>
                        </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}

        {activeTab === 'neural' && (
           <div className="animate-in fade-in duration-500">
              <div className="flex justify-between items-center mb-8">
                 <h3 className="text-xl font-black uppercase tracking-tight">Neural Market Intelligence</h3>
                 {neuralInsights && <button onClick={() => setNeuralInsights(null)} className="text-[10px] font-black uppercase text-gray-600 hover:text-white">New Analysis</button>}
              </div>
              
              {!neuralInsights ? (
                 <div className="glass-panel p-20 rounded-[40px] border border-white/5 flex flex-col items-center text-center space-y-10">
                    <div className="w-24 h-24 rounded-3xl bg-white/5 flex items-center justify-center"><svg className="w-12 h-12 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1" /></svg></div>
                    <div className="max-w-md">
                       <p className="text-gray-400 uppercase font-black text-xs tracking-widest leading-relaxed mb-10 italic">Identify client nodes for real-time gap analysis and predictive scaling.</p>
                       <div className="grid grid-cols-1 gap-3">
                          {clients.map(c => (
                             <button key={c.id} onClick={() => runNeuralAudit(c)} className="w-full py-4 px-6 rounded-2xl bg-white/5 border border-white/10 text-left hover:bg-[#9d00ff]/10 hover:border-[#9d00ff]/40 transition-all flex justify-between items-center group">
                                <span className="text-xs font-black uppercase tracking-widest">{c.name}</span>
                                <span className="text-[9px] font-black text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity uppercase">INITIATE SCAN →</span>
                             </button>
                          ))}
                       </div>
                    </div>
                 </div>
              ) : (
                <div className="space-y-8 animate-in slide-in-from-bottom-4">
                   <div className="glass-panel p-12 rounded-[40px] border-l-4 border-[#9d00ff] relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-8xl font-black uppercase -rotate-12 pointer-events-none">NEURAL</div>
                      <div className="flex justify-between items-start mb-8 relative z-10">
                         <div>
                            <h4 className="text-xs font-black uppercase tracking-[0.3em] text-[#9d00ff] mb-2">Subject: {neuralInsights.clientName}</h4>
                            <p className="text-4xl font-black tracking-tighter">HEALTH SCORE: <span className="text-white">{neuralInsights.healthScore}%</span></p>
                         </div>
                         <div className="text-right">
                            <div className="text-[10px] font-black uppercase text-gray-500 tracking-widest">Revenue Arbitrage</div>
                            <div className="text-2xl font-black text-[#88ff00]">{neuralInsights.revenuePotential}</div>
                         </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-12 relative z-10">
                         <div className="space-y-6">
                            <h5 className="text-[10px] font-black uppercase text-gray-600 tracking-[0.4em] mb-4">Neural Vector Gaps</h5>
                            <ul className="space-y-6">
                               {neuralInsights.recommendations.map((r: string, i: number) => (
                                 <li key={i} className="flex gap-4 text-sm text-gray-400 leading-relaxed italic border-b border-white/5 pb-4">
                                    <span className="text-[#88ff00] font-black">/ {i+1}</span> {r}
                                 </li>
                               ))}
                            </ul>
                         </div>
                         <div className="space-y-6">
                            <h5 className="text-[10px] font-black uppercase text-gray-600 tracking-[0.4em] mb-4">Adversary Matrix</h5>
                            <div className="flex flex-wrap gap-3">
                               {neuralInsights.competitors.map((c: string, i: number) => (
                                 <span key={i} className="px-6 py-3 rounded-2xl bg-white/5 border border-white/5 text-[10px] font-black uppercase tracking-widest text-gray-400 hover:text-white transition-colors">{c}</span>
                               ))}
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
              )}
           </div>
        )}

        {/* Client Provisioning Modal */}
        {isAddingClient && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-3xl p-6 overflow-y-auto">
             <div className="glass-panel w-full max-w-2xl p-12 rounded-[50px] border border-white/10 relative shadow-2xl my-8">
                <button onClick={() => setIsAddingClient(false)} className="absolute top-8 right-8 text-gray-500 hover:text-white p-2 transition-colors"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6" /></svg></button>
                <h3 className="text-3xl font-black uppercase tracking-tighter mb-10">Establish <span className="text-[#88ff00]">Enterprise</span> Link</h3>
                <form onSubmit={handleAddClient} className="grid grid-cols-2 gap-8">
                   <div className="space-y-2"><label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Entity Legal Name</label><input type="text" required value={newClient.name} onChange={(e) => setNewClient({ ...newClient, name: e.target.value })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold focus:border-[#88ff00] transition-colors" /></div>
                   <div className="space-y-2"><label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Primary Domain</label><input type="text" required value={newClient.domain} onChange={(e) => setNewClient({ ...newClient, domain: e.target.value })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold focus:border-[#88ff00] transition-colors" /></div>
                   <div className="space-y-2"><label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Target ARR</label><input type="text" required value={newClient.arr} onChange={(e) => setNewClient({ ...newClient, arr: e.target.value })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold focus:border-[#88ff00] transition-colors" /></div>
                   <div className="space-y-2"><label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Billing Tier</label><select value={newClient.billingStatus} onChange={(e) => setNewClient({ ...newClient, billingStatus: e.target.value as any })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold"><option value="Paid">A-Tier (Paid)</option><option value="Pending">B-Tier (Pending)</option></select></div>
                   
                   <div className="col-span-2 space-y-4">
                      <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Active Operational Protocols</label>
                      <div className="grid grid-cols-2 gap-4">
                         {Object.values(ServiceType).map(service => (
                           <label key={service} className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${newClient.activeServices?.includes(service) ? 'border-[#88ff00] bg-[#88ff00]/5' : 'border-white/5 bg-white/5 hover:bg-white/10'}`}>
                              <input 
                                type="checkbox" 
                                checked={newClient.activeServices?.includes(service)}
                                onChange={(e) => {
                                   const current = newClient.activeServices || [];
                                   const updated = e.target.checked ? [...current, service] : current.filter(s => s !== service);
                                   setNewClient({ ...newClient, activeServices: updated });
                                }}
                                className="hidden"
                              />
                              <div className={`w-4 h-4 rounded border flex items-center justify-center ${newClient.activeServices?.includes(service) ? 'bg-[#88ff00] border-[#88ff00]' : 'border-gray-700'}`}>
                                 {newClient.activeServices?.includes(service) && <svg className="w-3 h-3 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M5 13l4 4L19 7" /></svg>}
                              </div>
                              <span className="text-xs font-bold uppercase tracking-widest">{service}</span>
                           </label>
                         ))}
                      </div>
                   </div>

                   <button type="submit" className="col-span-2 py-6 rounded-3xl bg-white text-black font-black uppercase text-xs tracking-[0.3em] shadow-xl hover:bg-[#88ff00] transition-all transform active:scale-95">Commit To Roster</button>
                </form>
             </div>
          </div>
        )}

        {/* Client Edit Modal */}
        {editingClient && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-3xl p-6 overflow-y-auto">
             <div className="glass-panel w-full max-w-2xl p-12 rounded-[50px] border border-white/10 relative shadow-2xl my-8">
                <button onClick={() => setEditingClient(null)} className="absolute top-8 right-8 text-gray-500 hover:text-white p-2 transition-colors"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6" /></svg></button>
                <h3 className="text-3xl font-black uppercase tracking-tighter mb-10">Modify Profile: <span className="text-[#88ff00]">{editingClient.name}</span></h3>
                <form onSubmit={handleUpdateClient} className="grid grid-cols-2 gap-8">
                   <div className="space-y-2"><label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">ARR Update</label><input type="text" value={editingClient.arr} onChange={(e) => setEditingClient({ ...editingClient, arr: e.target.value })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold focus:border-[#88ff00]" /></div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Market Status</label>
                      <select value={editingClient.status} onChange={(e) => setEditingClient({ ...editingClient, status: e.target.value as any })} className="w-full bg-white/5 border border-white/10 rounded-2xl p-5 text-sm font-bold">
                         <option value="Active">Active</option>
                         <option value="Scaling">Scaling</option>
                         <option value="Authoritative">Authoritative</option>
                         <option value="Audit Phase">Audit Phase</option>
                      </select>
                   </div>
                   
                   <div className="col-span-2 space-y-4">
                      <label className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Active Protocols</label>
                      <div className="grid grid-cols-2 gap-4">
                         {Object.values(ServiceType).map(service => (
                           <label key={service} className={`flex items-center gap-3 p-4 rounded-xl border cursor-pointer transition-all ${editingClient.activeServices.includes(service) ? 'border-[#88ff00] bg-[#88ff00]/5' : 'border-white/5 bg-white/5 hover:bg-white/10'}`}>
                              <input 
                                type="checkbox" 
                                checked={editingClient.activeServices.includes(service)}
                                onChange={(e) => {
                                   const updated = e.target.checked ? [...editingClient.activeServices, service] : editingClient.activeServices.filter(s => s !== service);
                                   setEditingClient({ ...editingClient, activeServices: updated });
                                }}
                                className="hidden"
                              />
                              <div className={`w-4 h-4 rounded border flex items-center justify-center ${editingClient.activeServices.includes(service) ? 'bg-[#88ff00] border-[#88ff00]' : 'border-gray-700'}`}>
                                 {editingClient.activeServices.includes(service) && <svg className="w-3 h-3 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M5 13l4 4L19 7" /></svg>}
                              </div>
                              <span className="text-xs font-bold uppercase tracking-widest">{service}</span>
                           </label>
                         ))}
                      </div>
                   </div>

                   <button type="submit" className="col-span-2 py-6 rounded-3xl bg-white text-black font-black uppercase text-xs tracking-[0.3em] shadow-xl hover:bg-[#88ff00] transition-all transform active:scale-95">Commit Changes</button>
                </form>
             </div>
          </div>
        )}

        {/* Agency Hierarchy Management */}
        {activeTab === 'team' && canManageTeam && (
          <div className="space-y-6 animate-in fade-in duration-500">
             <h3 className="text-xl font-black uppercase tracking-tight mb-8">Agency Hierarchy</h3>
             {teamMembers.map((member) => (
               <div key={member.id} className="glass-panel p-8 rounded-3xl border border-white/5 flex items-center justify-between group">
                  <div className="flex gap-8 items-center">
                     <div className="w-14 h-14 rounded-full bg-white/5 flex items-center justify-center font-black text-gray-500 text-xl">{member.name.charAt(0)}</div>
                     <div>
                        <div className="text-sm font-black uppercase tracking-tight">{member.name}</div>
                        <div className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">{member.email}</div>
                     </div>
                  </div>
                  <div className="flex gap-12 items-center">
                     <div className="flex flex-col items-end">
                        <div className="px-4 py-1.5 rounded-full border text-[9px] font-black uppercase tracking-widest" style={{ color: ROLE_METADATA[member.role].color, borderColor: `${ROLE_METADATA[member.role].color}33` }}>
                          {member.role} // LVL {ROLE_METADATA[member.role].level}
                        </div>
                     </div>
                     <button onClick={() => handleEditMember(member)} className="p-3 rounded-xl bg-white/5 hover:bg-[#9d00ff]/20 text-gray-400 hover:text-[#9d00ff] transition-all"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 6V4m0 2a2 2 0 100 4" /></svg></button>
                  </div>
               </div>
             ))}
          </div>
        )}

        {/* Operational Authority Shift Modal */}
        {editingMember && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/95 backdrop-blur-2xl p-6">
             <div className="glass-panel w-full max-w-xl p-12 rounded-[50px] border border-white/10 relative shadow-2xl">
                <button onClick={() => { setEditingMember(null); setPendingRole(null); }} className="absolute top-8 right-8 text-gray-500 hover:text-white"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6" /></svg></button>
                <div className="text-center mb-10">
                   <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Authority Protocol</h3>
                   <p className="text-gray-500 text-xs font-bold uppercase tracking-widest">Assigning Operational Capacity for {editingMember.name}</p>
                </div>
                <div className="grid gap-4 mb-10">
                   {(['ADMIN', 'EDITOR', 'BILLING', 'VIEWER'] as AgencyRole[]).map((role) => {
                      const info = ROLE_METADATA[role];
                      const isSelected = pendingRole === role;
                      return (
                        <button key={role} onClick={() => setPendingRole(role)} className={`group relative p-6 rounded-3xl border transition-all text-left flex items-center justify-between ${isSelected ? 'border-[#88ff00] bg-[#88ff00]/10 ring-1 ring-[#88ff00]' : 'border-white/5 bg-white/5 hover:border-white/10'}`}>
                           <div>
                              <div className="flex items-center gap-2 mb-1">
                                 <span className={`text-xs font-black uppercase tracking-widest ${isSelected ? 'text-[#88ff00]' : 'text-white'}`}>{info.label}</span>
                                 <span className="text-[8px] font-black px-2 py-0.5 rounded-full bg-white/5 text-gray-500 border border-white/5">LVL {info.level}</span>
                              </div>
                              <p className="text-[10px] text-gray-500 uppercase tracking-tight font-bold">{info.desc}</p>
                           </div>
                           <div className="flex gap-1">
                              {Array.from({ length: 4 }).map((_, i) => (
                                <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all duration-500 ${info.level > i ? 'bg-[#88ff00]' : 'bg-white/5'}`} style={{ opacity: info.level > i ? (isSelected ? 1 : 0.3) : 0.1 }} />
                              ))}
                           </div>
                        </button>
                      );
                   })}
                </div>
                <button 
                  onClick={() => setIsConfirmingRole(true)}
                  disabled={!pendingRole || pendingRole === editingMember.role}
                  className="w-full py-6 rounded-3xl bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-all disabled:opacity-20"
                >
                  Request Protocol Shift
                </button>
             </div>
          </div>
        )}

        {/* Final Authority Confirmation */}
        {isConfirmingRole && editingMember && pendingRole && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/98 backdrop-blur-3xl animate-in fade-in duration-500">
             <div className="glass-panel w-full max-w-md p-12 rounded-[50px] border border-red-500/30 text-center relative shadow-[0_0_100px_rgba(255,0,85,0.15)]">
                <div className="w-24 h-24 bg-red-500/10 rounded-full mx-auto flex items-center justify-center mb-10 border border-red-500/20">
                   <svg className="w-12 h-12 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path d="M12 9v2m0 4h.01M3.34 16c-.77 1.333.192 3 1.732 3h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4" /></svg>
                </div>
                <h3 className="text-2xl font-black uppercase mb-6 text-red-500">Shift Authority Level?</h3>
                <p className="text-sm text-gray-400 leading-relaxed mb-12">You are permanently shifting the system access for <span className="text-white font-black">{editingMember.name}</span> to <span className="text-[#88ff00] font-black">{pendingRole}</span> protocol.</p>
                <div className="flex flex-col gap-4">
                   <button onClick={finalizeRoleShift} className="w-full py-5 rounded-2xl bg-red-500 text-white font-black uppercase text-xs tracking-widest shadow-xl">Confirm Shift</button>
                   <button onClick={() => setIsConfirmingRole(false)} className="w-full py-4 text-[10px] font-black uppercase tracking-widest text-gray-600 hover:text-white transition-colors">Abort Procedure</button>
                </div>
             </div>
          </div>
        )}

        {isAnalyzing && (
          <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black/95 backdrop-blur-2xl">
             <div className="w-24 h-24 border-4 border-[#88ff00] border-t-transparent rounded-full animate-spin mb-8 shadow-2xl" />
             <p className="text-3xl font-black uppercase tracking-tighter">Neural Market Scan...</p>
          </div>
        )}

        {isGeneratingAgreement && (
          <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-black/95 backdrop-blur-2xl animate-in fade-in">
             <div className="w-24 h-24 border-4 border-[#88ff00] border-t-transparent rounded-full animate-spin mb-8 shadow-2xl" />
             <p className="text-3xl font-black uppercase tracking-tighter">Drafting Global Counsel...</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default AgencyPortal;
