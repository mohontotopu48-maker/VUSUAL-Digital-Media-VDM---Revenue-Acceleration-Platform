
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Logo } from './Navbar';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const FloatingChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Welcome to VUSUAL Digital Media. I'm your growth assistant. How can I help you scale today?" }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatInstance = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isTyping, isOpen]);

  const initChat = () => {
    if (!chatInstance.current) {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      chatInstance.current = ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
          systemInstruction: 'You are the VUSUAL Support Assistant. You are concise, helpful, and sophisticated. You assist users with inquiries about SEO, PPC, ROI, and high-end marketing strategy. Keep responses brief and professional. Use a tone that reflects a premium boutique agency.'
        }
      });
    }
    return chatInstance.current;
  };

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    try {
      const chat = initChat();
      const result = await chat.sendMessageStream({ message: userMsg });
      
      let fullResponse = '';
      setMessages(prev => [...prev, { role: 'model', text: '' }]);

      for await (const chunk of result) {
        fullResponse += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1] = { role: 'model', text: fullResponse };
          return newMessages;
        });
      }
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { role: 'model', text: "I'm having a momentary connection issue. Please try again or contact us directly." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[70] flex flex-col items-end">
      {isOpen && (
        <div className="mega-menu-glass w-80 md:w-[400px] h-[550px] mb-6 rounded-[32px] overflow-hidden shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)] flex flex-col border border-white/10 animate-in slide-in-from-bottom-8 fade-in duration-500 ease-[cubic-bezier(0.23,1,0.32,1)]">
          {/* Luxury Header */}
          <div className="p-6 border-b border-white/10 bg-white/5 flex items-center justify-between backdrop-blur-2xl">
            <div className="flex items-center gap-3">
              <Logo className="w-8 h-8" />
              <div>
                <span className="block font-black text-xs tracking-[0.2em] uppercase text-white">VUSUAL Support</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#88ff00] animate-pulse" />
                  <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">Neural Link Active</span>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="p-2 rounded-full hover:bg-white/5 text-gray-500 hover:text-white transition-all duration-300"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide relative">
            <div className="mesh-blob bg-[#88ff00] -top-20 -left-20 opacity-[0.03]" />
            {messages.map((m, i) => (
              <div 
                key={i} 
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-500`}
              >
                <div className={`max-w-[88%] p-4 rounded-[22px] text-sm leading-relaxed shadow-xl ${
                  m.role === 'user' 
                    ? 'bg-gradient-to-br from-white to-gray-100 text-black font-semibold rounded-tr-none' 
                    : 'glass-panel border border-white/10 text-gray-200 rounded-tl-none backdrop-blur-md'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start animate-in fade-in duration-300">
                <div className="glass-panel border border-white/10 p-4 rounded-[22px] rounded-tl-none flex items-center gap-1.5 shadow-lg">
                  <div className="w-1.5 h-1.5 bg-[#88ff00] rounded-full animate-[typing_1.4s_infinite_ease-in-out]" />
                  <div className="w-1.5 h-1.5 bg-[#88ff00] rounded-full animate-[typing_1.4s_infinite_ease-in-out_0.2s]" />
                  <div className="w-1.5 h-1.5 bg-[#88ff00] rounded-full animate-[typing_1.4s_infinite_ease-in-out_0.4s]" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Luxury Input Bar */}
          <div className="p-6 border-t border-white/10 bg-black/40 backdrop-blur-xl">
            <div className="flex gap-3 items-center bg-white/5 border border-white/10 rounded-[20px] p-1 focus-within:border-[#88ff00]/50 transition-all duration-300">
              <input 
                type="text"
                placeholder="Briefly define your inquiry..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1 bg-transparent border-none px-4 py-3 text-sm focus:outline-none placeholder:text-gray-700 text-white font-medium"
              />
              <button 
                onClick={handleSend}
                disabled={isTyping || !input.trim()}
                className="p-3 rounded-[16px] bg-[#88ff00] text-black hover:scale-105 active:scale-95 transition-all duration-300 disabled:opacity-20 disabled:scale-100 shadow-[0_0_20px_rgba(136,255,0,0.3)]"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
              </button>
            </div>
            <p className="text-[9px] font-black text-gray-700 uppercase tracking-[0.3em] text-center mt-4">
              VUSUAL Neural Interface // v2.4
            </p>
          </div>
        </div>
      )}

      {/* Floating Action Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`p-5 rounded-[24px] transition-all duration-500 group shadow-[0_12px_32px_-4px_rgba(0,0,0,0.5)] flex items-center justify-center relative ${
          isOpen ? 'bg-white rotate-90' : 'neon-gradient shadow-[0_0_40px_rgba(136,255,0,0.4)] hover:scale-110'
        }`}
      >
        {isOpen ? (
          <svg className="w-6 h-6 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
        ) : (
          <>
            <svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-black group-hover:rotate-12 transition-transform">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-black" />
          </>
        )}
      </button>

      <style>{`
        @keyframes typing {
          0%, 100% { transform: translateY(0); opacity: 0.3; }
          50% { transform: translateY(-4px); opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default FloatingChat;
