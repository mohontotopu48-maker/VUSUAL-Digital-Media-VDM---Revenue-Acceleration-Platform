
import React from 'react';

interface PortalGatewayProps {
  onSelectClient: () => void;
  onSelectAgency: () => void;
}

const PortalGateway: React.FC<PortalGatewayProps> = ({ onSelectClient, onSelectAgency }) => {
  return (
    <section className="min-h-[85vh] flex items-center justify-center px-6 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-[#88ff00]/10 to-[#9d00ff]/10 rounded-full blur-[160px] opacity-40 animate-pulse pointer-events-none" />
      
      <div className="max-w-6xl w-full grid md:grid-cols-2 gap-10 relative z-10">
        {/* Client Prestige Portal Card */}
        <div 
          onClick={onSelectClient}
          className="glass-panel p-12 md:p-16 rounded-[48px] border-white/10 hover:border-[#88ff00]/50 transition-all group cursor-pointer hover:-translate-y-2 duration-500 flex flex-col items-center text-center"
        >
          <div className="w-24 h-24 rounded-3xl bg-white/5 flex items-center justify-center mb-10 group-hover:scale-110 transition-transform duration-500">
            <svg className="w-12 h-12 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tight mb-4">Client Prestige Portal</h2>
          <p className="text-gray-500 text-sm leading-relaxed mb-12 max-w-xs">
            Access real-time ROI auditing, neural campaign forecasts, and secure document vault for established enterprise accounts.
          </p>
          <button className="px-10 py-4 rounded-xl border border-[#88ff00]/30 text-[#88ff00] text-[10px] font-black uppercase tracking-widest group-hover:bg-[#88ff00] group-hover:text-black transition-all">
            Enter Client Nexus
          </button>
        </div>

        {/* Agency Master Gateway Card */}
        <div 
          onClick={onSelectAgency}
          className="glass-panel p-12 md:p-16 rounded-[48px] border-white/10 hover:border-[#9d00ff]/50 transition-all group cursor-pointer hover:-translate-y-2 duration-500 flex flex-col items-center text-center"
        >
          <div className="w-24 h-24 rounded-3xl bg-white/5 flex items-center justify-center mb-10 group-hover:scale-110 transition-transform duration-500">
            <svg className="w-12 h-12 text-[#9d00ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tight mb-4">Master Admin Command</h2>
          <p className="text-gray-500 text-sm leading-relaxed mb-12 max-w-xs">
            High-fidelity operational control over global revenue metrics, client provisioning, and neural strategic modeling.
          </p>
          <button className="px-10 py-4 rounded-xl border border-[#9d00ff]/30 text-[#9d00ff] text-[10px] font-black uppercase tracking-widest group-hover:bg-[#9d00ff] group-hover:text-white transition-all">
            Access Operations Center
          </button>
        </div>
      </div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 text-[9px] font-black text-gray-700 uppercase tracking-[0.5em] animate-pulse">
        System Protocol: Encrypted Entry Only
      </div>
    </section>
  );
};

export default PortalGateway;
