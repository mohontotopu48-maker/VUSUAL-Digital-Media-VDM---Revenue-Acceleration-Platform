
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { decodeBase64Audio, decodeAudioBuffer } from '../services/geminiService';

interface LiveConsultantProps {
  onClose: () => void;
}

type StrategyFocus = 'GENERAL' | 'SEO' | 'PPC' | 'CONVERSION';

const LiveConsultant: React.FC<LiveConsultantProps> = ({ onClose }) => {
  const [status, setStatus] = useState<'connecting' | 'active' | 'error'>('connecting');
  const [onboardingStep, setOnboardingStep] = useState(0); 
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [strategyFocus, setStrategyFocus] = useState<StrategyFocus>('GENERAL');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  let nextStartTime = 0;

  const getSystemInstruction = (focus: StrategyFocus) => {
    const base = "You are the Visual Digital Media (VDM) AI Consultant. You are professional, high-end, and authoritative. Your goal is to help the user scale their digital revenue using advanced data-driven strategies.";
    switch (focus) {
      case 'SEO': return `${base} Focus specifically on organic dominance, technical SEO infrastructure, and content velocity.`;
      case 'PPC': return `${base} Focus on high-ROAS paid acquisition, algorithmic bidding strategies, and lower CAC.`;
      case 'CONVERSION': return `${base} Focus on CRO science, user psychological triggers, and friction elimination in the sales funnel.`;
      default: return `${base} Provide a holistic overview of SEO, PPC, and Creative synergy.`;
    }
  };

  const startSession = async () => {
    try {
      // Strictly following initialization guidelines: new instance right before connection
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: getSystemInstruction(strategyFocus),
          speechConfig: { 
            voiceConfig: { 
              prebuiltVoiceConfig: { voiceName: 'Kore' } 
            } 
          },
          // Added transcription for better accessibility/feedback
          outputAudioTranscription: {},
          inputAudioTranscription: {}
        },
        callbacks: {
          onopen: () => {
            setStatus('active');
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const input = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(input.length);
              for (let i = 0; i < input.length; i++) int16[i] = input[i] * 32768;
              
              const encode = (bytes: Uint8Array) => {
                let binary = '';
                const len = bytes.byteLength;
                for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
                return btoa(binary);
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({
                  media: {
                    data: encode(new Uint8Array(int16.buffer)),
                    mimeType: 'audio/pcm;rate=16000'
                  }
                });
              });
            };
            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (msg) => {
            const audioData = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              setIsSpeaking(true);
              const bytes = decodeBase64Audio(audioData);
              const buffer = await decodeAudioBuffer(bytes, audioContextRef.current);
              
              const source = audioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContextRef.current.destination);
              
              nextStartTime = Math.max(nextStartTime, audioContextRef.current.currentTime);
              source.start(nextStartTime);
              nextStartTime += buffer.duration;
              
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              };
              sourcesRef.current.add(source);
            }
            
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTime = 0;
              setIsSpeaking(false);
            }
          },
          onerror: (e) => {
            console.error('Session error:', e);
            setStatus('error');
          },
          onclose: () => setStatus('connecting')
        }
      });
      
      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start session:', err);
      setStatus('error');
    }
  };

  const handleNextOnboarding = () => {
    if (onboardingStep < 2) {
      setOnboardingStep(prev => prev + 1);
    } else {
      setOnboardingStep(3); // Completed
      startSession();
    }
  };

  useEffect(() => {
    return () => {
      sessionRef.current?.close();
      audioContextRef.current?.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/95 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="glass-panel w-full max-w-2xl p-10 md:p-14 rounded-[40px] md:rounded-[60px] border border-white/10 text-center relative overflow-hidden shadow-2xl">
        
        {/* Progress Bar */}
        <div className="absolute top-0 left-0 right-0 h-1 flex">
          {[0, 1, 2, 3].map(i => (
            <div 
              key={i} 
              className={`flex-1 transition-all duration-700 ${onboardingStep >= i ? 'bg-[#88ff00]' : 'bg-white/5'}`} 
            />
          ))}
        </div>

        <button 
          onClick={onClose}
          className="absolute top-8 right-8 text-gray-500 hover:text-white transition-colors z-10 p-2 hover:bg-white/5 rounded-full"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        {onboardingStep < 3 ? (
          <div className="animate-in slide-in-from-bottom-8 duration-700">
            {onboardingStep === 0 && (
              <div className="space-y-10">
                <div className="relative inline-block">
                  <div className="w-24 h-24 bg-white text-black rounded-3xl mx-auto flex items-center justify-center text-4xl font-black shadow-xl shadow-white/10 rotate-3">V</div>
                  <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-[#88ff00] rounded-lg flex items-center justify-center animate-bounce shadow-lg">
                    <svg className="w-4 h-4 text-black" fill="currentColor" viewBox="0 0 20 20"><path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" /></svg>
                  </div>
                </div>
                <div>
                  <h3 className="text-4xl md:text-5xl font-black mb-4 uppercase tracking-tighter">Strategic <span className="neon-text">Uplink</span></h3>
                  <p className="text-gray-400 text-lg max-w-md mx-auto leading-relaxed">
                    You are initializing a real-time neural connection with our senior growth architects. 
                    <span className="block mt-4 text-sm font-bold text-gray-500 uppercase tracking-widest">Protocol: Direct Voice Interaction</span>
                  </p>
                </div>
              </div>
            )}

            {onboardingStep === 1 && (
              <div className="space-y-10">
                <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#88ff00] mb-2">SEQUENCE 02 // DEFINE FOCUS</h4>
                <div className="grid grid-cols-2 gap-4">
                  {(['GENERAL', 'SEO', 'PPC', 'CONVERSION'] as const).map((focus) => (
                    <button
                      key={focus}
                      onClick={() => setStrategyFocus(focus)}
                      className={`p-6 rounded-2xl border transition-all text-left group ${
                        strategyFocus === focus 
                        ? 'border-[#88ff00] bg-[#88ff00]/10 ring-1 ring-[#88ff00]' 
                        : 'border-white/5 bg-white/5 hover:border-white/20'
                      }`}
                    >
                      <div className={`text-[10px] font-black uppercase tracking-widest mb-2 ${strategyFocus === focus ? 'text-[#88ff00]' : 'text-gray-500'}`}>
                        {focus}
                      </div>
                      <div className="text-sm font-bold text-white uppercase group-hover:translate-x-1 transition-transform">
                        {focus === 'GENERAL' ? 'Full Stack' : focus === 'CONVERSION' ? 'CRO Engine' : `${focus} Mastery`}
                      </div>
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 italic">"Focusing the model's neural weights on your primary KPI channel."</p>
              </div>
            )}

            {onboardingStep === 2 && (
              <div className="space-y-10">
                 <div className="w-24 h-24 rounded-full border border-white/10 mx-auto flex items-center justify-center relative bg-white/5">
                    <div className="absolute inset-0 border-2 border-[#88ff00] rounded-full animate-ping opacity-20" />
                    <svg className="w-10 h-10 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                 </div>
                 <div>
                    <h3 className="text-3xl font-black mb-4 uppercase tracking-tighter">Prepare For Dialogue</h3>
                    <ul className="text-left space-y-4 max-w-sm mx-auto">
                      <li className="flex items-start gap-3 text-sm text-gray-400">
                        <span className="text-[#88ff00] font-black">01.</span> Speak clearly when the central pulse becomes active.
                      </li>
                      <li className="flex items-start gap-3 text-sm text-gray-400">
                        <span className="text-[#88ff00] font-black">02.</span> Interrupt freely—the system adjusts to your conversational flow.
                      </li>
                      <li className="flex items-start gap-3 text-sm text-gray-400">
                        <span className="text-[#88ff00] font-black">03.</span> Provide specific URLs or revenue targets for deeper analysis.
                      </li>
                    </ul>
                 </div>
              </div>
            )}

            <div className="mt-14 flex flex-col items-center gap-6">
              <button 
                onClick={handleNextOnboarding}
                className="px-14 py-5 rounded-2xl neon-gradient text-black font-black uppercase text-xs tracking-[0.2em] hover:scale-105 transition-all shadow-xl shadow-[#88ff00]/20 active:scale-95"
              >
                {onboardingStep === 2 ? 'ESTABLISH LINK →' : 'NEXT SEQUENCE'}
              </button>
              <div className="flex gap-2">
                {[0, 1, 2].map(i => (
                  <div key={i} className={`w-10 h-1 rounded-full transition-all duration-500 ${onboardingStep === i ? 'bg-[#88ff00] w-16' : 'bg-white/10'}`} />
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in zoom-in-95 duration-1000">
            <div className="mb-14 relative flex justify-center">
              <div className={`w-48 h-48 rounded-full neon-gradient flex items-center justify-center transition-all duration-500 ${isSpeaking ? 'scale-110 shadow-[0_0_80px_rgba(136,255,0,0.6)]' : 'scale-100 shadow-[0_0_20px_rgba(255,255,255,0.05)]'}`}>
                <div className="w-44 h-44 rounded-full bg-[#050505] flex items-center justify-center overflow-hidden relative">
                   <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]" />
                   <div className="absolute inset-0 bg-grid opacity-10" />
                   
                  <div className={`w-20 h-20 rounded-2xl bg-white transition-all duration-700 flex items-center justify-center group ${isSpeaking ? 'rotate-[135deg] scale-75 rounded-[40px]' : 'rotate-0 scale-100'}`}>
                     <div className="w-6 h-6 bg-black rounded-sm animate-pulse" />
                  </div>
                </div>
              </div>
              {isSpeaking && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-72 h-72 border border-[#88ff00] rounded-full animate-ping opacity-10" />
                  <div className="w-64 h-64 border border-[#9d00ff] rounded-full animate-ping opacity-5" style={{ animationDelay: '0.3s' }} />
                </div>
              )}
            </div>

            <div className="space-y-2 mb-10">
              <h3 className="text-4xl font-black uppercase tracking-tighter">Consultant <span className="text-[#88ff00]">Online</span></h3>
              <p className="text-[#88ff00] uppercase tracking-[0.5em] font-black text-[10px] animate-pulse">
                {status === 'active' ? `PROTOCOL: ${strategyFocus} OPTIMIZED` : status === 'connecting' ? 'SYNCING NEURAL CORES...' : 'LINK TERMINATED'}
              </p>
            </div>
            
            <div className="glass-panel p-6 rounded-3xl border-white/5 mb-10 min-h-[100px] flex items-center justify-center">
              <p className="text-gray-300 text-lg leading-relaxed max-w-md italic">
                {isSpeaking ? "Analyzing market signals..." : "I'm listening. Define your objective."}
              </p>
            </div>

            <div className="flex justify-center gap-6">
              <div className="flex gap-2 h-12 items-end">
                {Array.from({ length: 16 }).map((_, i) => (
                  <div 
                    key={i} 
                    className={`w-1.5 bg-gradient-to-t from-[#88ff00] to-[#9d00ff] rounded-full transition-all duration-300 ${isSpeaking ? '' : 'h-2 opacity-20'}`}
                    style={{ 
                      height: isSpeaking ? `${20 + Math.random() * 80}%` : '8px', 
                      animation: isSpeaking ? `neural-vibe ${1 + Math.random()}s infinite alternate ease-in-out` : 'none',
                      animationDelay: `${i * 0.05}s`
                    }} 
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      <style>{`
        @keyframes neural-vibe {
          0% { transform: scaleY(0.8); opacity: 0.5; }
          100% { transform: scaleY(1.2); opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default LiveConsultant;
