
import React, { useState, useRef, useEffect } from 'react';
import { PageState, User } from '../types';

interface SubService {
  id: string;
  name: string;
  desc: string;
  icon: React.ReactNode;
}

interface ServiceCategory {
  category: string;
  subServices: SubService[];
}

const serviceCatalog: ServiceCategory[] = [
  {
    category: 'SEO Infrastructure',
    subServices: [
      { 
        id: 'national-seo',
        name: 'National SEO', 
        desc: 'Dominating enterprise search landscapes.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-.856.12-1.685.344-2.468" /></svg>
      },
      { 
        id: 'ghl-management',
        name: 'Nexus GHL', 
        desc: 'Advanced CRM & funnel engineering.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
      },
    ]
  },
  {
    category: 'Paid Media',
    subServices: [
      { 
        id: 'google-ads',
        name: 'Google Ads', 
        desc: 'ROAS-engineered search campaigns.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M15.042 21.672L13.684 16.6m0 0l-2.51 2.225.569-9.47 5.227 7.917-3.286-.672zm-7.518-.267A8.25 8.25 0 1120.25 10.5M8.288 14.212A5.25 5.25 0 1117.25 10.5" /></svg>
      },
      { 
        id: 'paid-social',
        name: 'Paid Social', 
        desc: 'Meta, LinkedIn & TikTok mastery.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" /></svg>
      },
    ]
  },
  {
    category: 'Social & Brand',
    subServices: [
      { 
        id: 'social-media-management',
        name: 'Social Mgmt', 
        desc: 'High-fidelity community authority.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-4.682-2.72m.94 3.198l.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0112 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 016 18.719m12 0a5.971 5.971 0 00-.941-3.197m0 0A5.995 5.995 0 0012 12.75a5.995 5.995 0 00-5.058 2.772m0 0a5.971 5.971 0 00-.94 3.197M15 6.75a3 3 0 11-6 0 3 3 0 016 0zm6 3a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0zm-13.5 0a2.25 2.25 0 11-4.5 0 2.25 2.25 0 014.5 0z" /></svg>
      },
      { 
        id: 'custom-design',
        name: 'Prestige Design', 
        desc: 'Bespoke high-ticket UI/UX.',
        icon: <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>
      },
    ]
  }
];

export const Logo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => (
  <div className={`${className} relative`}>
    <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-[0_0_8px_rgba(230,0,126,0.3)]">
      <circle cx="50" cy="50" r="50" fill="#E6007E" />
      <path d="M22 25H38L50 62L62 25H78L55 85H45L22 25Z" fill="white" />
      <path d="M47 52L53 38L51 68L44 52H47Z" fill="#E6007E" />
    </svg>
  </div>
);

interface NavbarProps {
  onNavigate: (page: PageState) => void;
  onNavigateToService: (id: string) => void;
  currentPage: PageState;
  user: User | null;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, onNavigateToService, currentPage, user, onLogout }) => {
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isMegaMenuRendered, setIsMegaMenuRendered] = useState(false);
  const [isMegaMenuVisible, setIsMegaMenuVisible] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  
  const showTimeoutRef = useRef<number | null>(null);
  const hideTimeoutRef = useRef<number | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const clearTimeouts = () => {
    if (showTimeoutRef.current) window.clearTimeout(showTimeoutRef.current);
    if (hideTimeoutRef.current) window.clearTimeout(hideTimeoutRef.current);
  };

  const closeMenuDecisively = () => {
    clearTimeouts();
    setIsMegaMenuVisible(false);
    setIsMegaMenuRendered(false);
    setIsMobileOpen(false);
    setIsProfileOpen(false);
  };

  const handleMouseEnter = () => {
    clearTimeouts();
    if (!isMegaMenuRendered) {
      showTimeoutRef.current = window.setTimeout(() => {
        setIsMegaMenuRendered(true);
        setTimeout(() => setIsMegaMenuVisible(true), 10);
      }, 150);
    } else {
      setIsMegaMenuVisible(true);
    }
  };

  const handleMouseLeave = () => {
    clearTimeouts();
    hideTimeoutRef.current = window.setTimeout(() => {
      setIsMegaMenuVisible(false);
      hideTimeoutRef.current = window.setTimeout(() => {
        setIsMegaMenuRendered(false);
      }, 300);
    }, 400);
  };

  const navItems = [
    { label: 'Audit Engine', state: PageState.AUDIT },
    { label: 'ROI Tools', state: PageState.CALCULATOR },
    { label: 'AI Studio', state: PageState.AI_STUDIO },
  ];

  const isPortalActive = currentPage === PageState.CLIENT_PORTAL || currentPage === PageState.AGENCY_PORTAL || currentPage === PageState.PORTAL_GATEWAY;

  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-40 transition-opacity duration-700 pointer-events-none ${isMegaMenuVisible ? 'opacity-100' : 'opacity-0'}`} 
      />

      <nav className="fixed top-0 left-0 right-0 z-50 glass-panel border-b border-white/5" ref={menuRef}>
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div 
            onClick={() => { onNavigate(PageState.HOME); closeMenuDecisively(); }}
            className="flex items-center gap-4 cursor-pointer group"
          >
            <Logo className="w-10 h-10 group-hover:scale-110 transition-transform duration-500" />
            <span className="text-xl font-black tracking-tighter uppercase hidden sm:block">VUSUAL <span className="text-gray-500 font-bold">Digital Media</span></span>
          </div>

          <div className="hidden lg:flex items-center gap-8">
            <div className="relative" onMouseEnter={handleMouseEnter} onMouseLeave={handleMouseLeave}>
              <button
                className={`text-sm font-semibold tracking-wide transition-colors h-20 flex items-center gap-1 group ${
                  isMegaMenuVisible ? 'text-[#88ff00]' : 'text-gray-400 hover:text-white'
                }`}
              >
                Services
                <svg className={`w-4 h-4 transition-transform duration-300 ${isMegaMenuVisible ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {isMegaMenuRendered && (
                <div 
                  className={`absolute top-full -left-48 mt-0 w-[840px] mega-menu-glass rounded-b-[32px] border-x border-b border-white/10 p-10 shadow-2xl transition-all duration-300 ease-out transform ${
                    isMegaMenuVisible 
                      ? 'opacity-100 translate-y-0 scale-100' 
                      : 'opacity-0 -translate-y-2 scale-95 pointer-events-none'
                  }`}
                >
                  <div className="grid grid-cols-3 gap-10">
                    {serviceCatalog.map((cat) => (
                      <div key={cat.category}>
                        <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-[#88ff00] mb-6">{cat.category}</h4>
                        <ul className="space-y-6">
                          {cat.subServices.map((sub) => (
                            <li 
                              key={sub.id} 
                              onClick={() => { onNavigateToService(sub.id); closeMenuDecisively(); }}
                              className="group cursor-pointer flex items-start gap-4 p-2 -ml-2 rounded-xl hover:bg-white/5 transition-all"
                            >
                              <div className="mt-1 w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-gray-500 group-hover:text-[#88ff00] group-hover:bg-[#88ff00]/10 transition-all">
                                {sub.icon}
                              </div>
                              <div>
                                <h5 className="text-sm font-bold text-white group-hover:text-[#88ff00] transition-colors">{sub.name}</h5>
                                <p className="text-[11px] text-gray-500 leading-snug mt-1 group-hover:text-gray-400">{sub.desc}</p>
                              </div>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => { onNavigate(item.state); closeMenuDecisively(); }}
                className={`text-sm font-semibold tracking-wide transition-colors ${
                  currentPage === item.state ? 'text-[#88ff00]' : 'text-gray-400 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
            
            <div className="flex items-center gap-4">
              {user ? (
                <div className="relative">
                  <button 
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center gap-3 px-4 py-2 rounded-full glass-panel border border-white/10 hover:border-[#88ff00]/50 transition-all"
                  >
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-[#88ff00] to-[#9d00ff] flex items-center justify-center text-[10px] font-black text-black">
                      {user.name.charAt(0)}
                    </div>
                    <span className="text-xs font-bold tracking-tight">{user.name}</span>
                  </button>
                  {isProfileOpen && (
                    <div className="absolute top-full right-0 mt-2 w-48 glass-panel rounded-2xl border border-white/10 p-2 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
                      <button 
                        onClick={() => { onNavigate(user.role === 'AGENCY' ? PageState.AGENCY_PORTAL : PageState.CLIENT_PORTAL); setIsProfileOpen(false); }}
                        className="w-full text-left px-4 py-3 text-xs font-bold text-gray-400 hover:text-[#88ff00] hover:bg-white/5 rounded-xl transition-all"
                      >
                        {user.role === 'AGENCY' ? 'Agency Dashboard' : 'Client Portal'}
                      </button>
                      <button 
                        onClick={() => { onLogout(); setIsProfileOpen(false); }}
                        className="w-full text-left px-4 py-3 text-xs font-bold text-red-400 hover:text-red-300 hover:bg-red-500/5 rounded-xl transition-all"
                      >
                        Sign Out
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button 
                  onClick={() => { onNavigate(PageState.PORTAL_GATEWAY); closeMenuDecisively(); }}
                  className={`text-xs font-black uppercase tracking-widest px-5 py-2.5 rounded-full border transition-all ${
                    isPortalActive ? 'bg-[#88ff00] text-black border-[#88ff00]' : 'border-white/10 text-gray-400 hover:text-white hover:border-white/40'
                  }`}
                >
                  Portal Access
                </button>
              )}
              <button 
                onClick={() => { onNavigate(PageState.AUDIT); closeMenuDecisively(); }}
                className="px-6 py-2.5 rounded-full bg-white text-black text-sm font-bold hover:bg-[#88ff00] transition-all transform hover:scale-105 shadow-xl shadow-white/5"
              >
                Get Audit
              </button>
            </div>
          </div>

          <button className="lg:hidden" onClick={() => setIsMobileOpen(!isMobileOpen)}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMobileOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
            </svg>
          </button>
        </div>

        {isMobileOpen && (
          <div className="lg:hidden glass-panel border-t border-white/5 p-6 h-[calc(100vh-80px)] overflow-y-auto animate-in slide-in-from-top duration-300">
            <div className="flex flex-col gap-8">
              <div className="space-y-6">
                 <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 mb-2">Our Solutions</h4>
                 {serviceCatalog.map((cat) => (
                   <div key={cat.category} className="space-y-3">
                      <div className="text-sm font-bold text-[#88ff00]">{cat.category}</div>
                      <div className="pl-4 space-y-4">
                         {cat.subServices.map((sub) => (
                           <div 
                             key={sub.id} 
                             onClick={() => { onNavigateToService(sub.id); closeMenuDecisively(); }}
                             className="flex items-start gap-3 cursor-pointer group"
                            >
                              <div className="mt-0.5 w-6 h-6 rounded bg-white/5 flex items-center justify-center text-gray-600 group-hover:text-[#88ff00]">
                                {sub.icon}
                              </div>
                              <div className="text-sm font-medium text-gray-300 group-hover:text-white transition-colors">{sub.name}</div>
                           </div>
                         ))}
                      </div>
                   </div>
                 ))}
              </div>
              <div className="h-px w-full bg-white/5" />
              {navItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => { onNavigate(item.state); closeMenuDecisively(); }}
                  className={`text-lg font-bold text-left ${
                    currentPage === item.state ? 'text-[#88ff00]' : 'text-gray-400'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <button 
                onClick={() => { onNavigate(PageState.PORTAL_GATEWAY); closeMenuDecisively(); }}
                className="text-lg font-bold text-left text-gray-400"
              >
                {user ? `Go to Dashboard (${user.role})` : 'Portal Access'}
              </button>
              {user && (
                <button 
                  onClick={() => { onLogout(); closeMenuDecisively(); }}
                  className="text-lg font-bold text-left text-red-500"
                >
                  Log Out
                </button>
              )}
              <button 
                 onClick={() => { onNavigate(PageState.AUDIT); closeMenuDecisively(); }}
                className="w-full py-4 rounded-xl neon-gradient text-black font-black uppercase text-center shadow-lg shadow-[#88ff00]/20"
              >
                Get Free Audit
              </button>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
