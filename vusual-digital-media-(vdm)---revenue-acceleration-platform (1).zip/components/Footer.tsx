
import React from 'react';
import { Logo } from './Navbar';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#050505] border-t border-white/5 pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-24">
        <div className="col-span-2">
          <div className="flex items-center gap-4 mb-8">
            <Logo className="w-12 h-12" />
            <span className="text-2xl font-black tracking-tighter uppercase">VUSUAL <span className="text-gray-500">Digital Media</span></span>
          </div>
          <p className="text-gray-400 text-lg max-w-sm mb-8">
            The world's first hybrid performance agency designed for the age of intelligence. Data precision meets boutique prestige.
          </p>
          <div className="flex gap-4">
            {['Twitter', 'LinkedIn', 'Clutch', 'Awwwards'].map((s) => (
              <a key={s} href="#" className="text-xs font-bold uppercase tracking-widest text-gray-500 hover:text-[#88ff00] transition-colors">{s}</a>
            ))}
          </div>
        </div>
        
        <div>
          <h5 className="font-bold uppercase tracking-widest text-xs mb-8 text-white">Platform</h5>
          <ul className="space-y-4 text-gray-500 font-medium">
            <li><a href="#" className="hover:text-white">Revenue Audit</a></li>
            <li><a href="#" className="hover:text-white">ROI Modeling</a></li>
            <li><a href="#" className="hover:text-white">AI Creative Studio</a></li>
            <li><a href="#" className="hover:text-white">Client Portal</a></li>
          </ul>
        </div>

        <div>
          <h5 className="font-bold uppercase tracking-widest text-xs mb-8 text-white">Contact</h5>
          <ul className="space-y-4 text-gray-500 font-medium">
            <li>London, UK</li>
            <li>New York, NY</li>
            <li>hello@vusualdm.com</li>
            <li className="text-[#88ff00] font-black uppercase tracking-widest">+1 (888) REVENUE</li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8 border-t border-white/5 pt-12">
        <p className="text-gray-600 text-sm">© 2024 VUSUAL Digital Media. All rights reserved. Revenue Acceleration is a trademark of VDM Group.</p>
        <div className="flex gap-8 text-xs font-bold text-gray-600 uppercase tracking-widest">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="#">Cookies</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
