
import React, { useState } from 'react';
import { performAudit } from '../services/geminiService';
import { AuditResult } from '../types';

interface AuditToolProps {
  onComplete?: () => void;
}

const AuditTool: React.FC<AuditToolProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({ url: '', industry: '', budget: '' });
  const [result, setResult] = useState<AuditResult | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const audit = await performAudit(formData.url, formData.industry);
      setResult({ ...audit, url: formData.url });
      setStep(3);
      if (onComplete) onComplete();
    } catch (err) {
      console.error(err);
      alert("Audit failed. This might be due to market volatility or site accessibility. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleClaimSession = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setIsSuccess(true);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <section className="py-24 px-6 max-w-4xl mx-auto text-center animate-in fade-in zoom-in-95 duration-1000">
        <div className="glass-panel p-20 rounded-[60px] border-[#88ff00]/30 shadow-[0_0_100px_rgba(136,255,0,0.1)]">
           <div className="w-24 h-24 bg-[#88ff00] rounded-full mx-auto flex items-center justify-center mb-10">
              <svg className="w-12 h-12 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
           </div>
           <h2 className="text-4xl font-black uppercase tracking-tighter mb-6">Uplink Confirmed</h2>
           <p className="text-gray-400 text-lg mb-12 max-w-md mx-auto leading-relaxed">
             Our growth architects have received your audit data. A senior strategist will reach out within <span className="text-white font-bold italic">2 operational hours</span> to initialize your roadmap.
           </p>
           <button onClick={() => { setIsSuccess(false); setStep(1); setResult(null); }} className="px-10 py-5 rounded-2xl bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-colors">Return to Hub</button>
        </div>
      </section>
    );
  }

  return (
    <section className="py-24 px-6 max-w-4xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4 tracking-tighter uppercase">VUSUAL <span className="neon-text">REVENUE</span> AUDIT</h2>
        <p className="text-gray-400 text-lg">Harness real-time market intelligence to expose your competition's weaknesses.</p>
      </div>

      <div className="glass-panel rounded-[40px] p-8 md:p-12 relative overflow-hidden border-white/10">
        {loading && (
          <div className="absolute inset-0 bg-black/90 z-20 flex flex-col items-center justify-center space-y-6">
            <div className="w-20 h-20 border-t-4 border-[#88ff00] rounded-full animate-spin" />
            <div className="text-center">
              <p className="text-[#88ff00] font-black text-xl animate-pulse tracking-widest uppercase">CRAWLING ASSETS</p>
              <p className="text-xs text-gray-500 mt-2">Checking search indexes, social velocity, and conversion signals...</p>
            </div>
          </div>
        )}

        {step === 1 && (
          <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div>
              <label className="block text-xs font-black uppercase tracking-[0.3em] text-gray-500 mb-4">Enterprise Domain</label>
              <input 
                type="text" 
                placeholder="company.com"
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-xl focus:outline-none focus:border-[#88ff00] transition-all placeholder:text-gray-700 font-bold"
              />
            </div>
            <button 
              onClick={() => setStep(2)}
              disabled={!formData.url}
              className="w-full py-6 rounded-2xl neon-gradient text-black font-black text-xl hover:scale-[1.02] transition-all disabled:opacity-20 shadow-xl shadow-[#88ff00]/20"
            >
              INITIALIZE VUSUAL ANALYSIS
            </button>
          </div>
        )}

        {step === 2 && (
          <form onSubmit={handleSubmit} className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.3em] text-gray-500 mb-4">Market Vertical</label>
                <select 
                  value={formData.industry}
                  onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-lg focus:outline-none focus:border-[#88ff00] transition-colors appearance-none cursor-pointer font-bold"
                >
                  <option value="">Choose Industry</option>
                  <option value="SaaS">SaaS / Cloud</option>
                  <option value="Fintech">Fintech / Web3</option>
                  <option value="Luxury">Luxury / Retail</option>
                  <option value="Health">Healthcare</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.3em] text-gray-500 mb-4">Growth Objective</label>
                <input 
                  type="text" 
                  placeholder="e.g. 5x Revenue"
                  value={formData.budget}
                  onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-lg focus:outline-none focus:border-[#88ff00] transition-colors font-bold"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <button onClick={() => setStep(1)} type="button" className="px-10 py-6 rounded-2xl bg-white/5 font-bold hover:bg-white/10 transition-colors uppercase text-xs tracking-widest">BACK</button>
              <button type="submit" className="flex-1 py-6 rounded-2xl neon-gradient text-black font-black text-xl hover:scale-[1.02] transition-all shadow-xl shadow-[#88ff00]/20">GENERATE MASTER AUDIT</button>
            </div>
          </form>
        )}

        {step === 3 && result && (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="flex flex-col md:flex-row gap-12 items-center mb-12 border-b border-white/5 pb-12">
              <div className="w-48 h-48 rounded-full border-[10px] border-[#88ff00] flex flex-col items-center justify-center relative shadow-[0_0_50px_rgba(136,255,0,0.1)]">
                <span className="text-6xl font-black">{result.healthScore}</span>
                <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Score</span>
              </div>
              <div className="text-center md:text-left">
                <h3 className="text-3xl font-black mb-3 uppercase tracking-tighter">REVENUE POTENTIAL: <span className="text-[#88ff00]">{result.revenuePotential}</span></h3>
                <p className="text-gray-400 max-w-lg leading-relaxed text-sm">VUSUAL intelligence identifies massive arbitrage opportunities for <span className="text-white font-bold underline decoration-[#88ff00] decoration-2">{result.url}</span> in the current market landscape.</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8 mb-12">
              <div className="glass-panel p-8 rounded-3xl border-l-4 border-[#88ff00]">
                <h4 className="font-black mb-6 uppercase text-xs tracking-[0.3em] text-[#88ff00]">Strategic Gaps</h4>
                <ul className="space-y-4">
                  {result.recommendations.map((rec, i) => (
                    <li key={i} className="flex gap-3 text-sm text-gray-300 leading-relaxed italic">
                      <svg className="w-5 h-5 text-[#88ff00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="glass-panel p-8 rounded-3xl border-l-4 border-[#9d00ff]">
                <h4 className="font-black mb-6 uppercase text-xs tracking-[0.3em] text-[#9d00ff]">Primary Adversaries</h4>
                <div className="flex flex-wrap gap-2">
                  {result.competitors.map((comp, i) => (
                    <span key={i} className="px-4 py-2 rounded-xl bg-white/5 text-xs font-bold text-gray-400 border border-white/5 uppercase tracking-tighter">{comp}</span>
                  ))}
                </div>
              </div>
            </div>

            {result.sources && result.sources.length > 0 && (
              <div className="mb-12">
                <h4 className="font-black mb-4 uppercase text-[10px] tracking-[0.3em] text-gray-600">VUSUAL Intelligence Sources</h4>
                <div className="flex flex-wrap gap-4">
                  {result.sources.map((src, i) => (
                    <a key={i} href={src.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-[#88ff00] hover:underline flex items-center gap-1 font-bold">
                      {src.title || 'Market Source'}
                      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                    </a>
                  ))}
                </div>
              </div>
            )}

            <button onClick={handleClaimSession} className="w-full py-6 rounded-2xl bg-white text-black font-black text-xl hover:bg-[#88ff00] transition-all transform hover:scale-[1.01] shadow-[0_20px_40px_rgba(0,0,0,0.3)] uppercase tracking-tighter">
              CLAIM STRATEGY SESSION
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default AuditTool;
