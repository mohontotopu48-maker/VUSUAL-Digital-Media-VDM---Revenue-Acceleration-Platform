
import React from 'react';

interface HeroProps {
  onStartAudit: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStartAudit }) => {
  return (
    <section className="relative pt-20 pb-32 overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-[#88ff00] rounded-full blur-[120px] opacity-10 animate-pulse" />
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-[#9d00ff] rounded-full blur-[120px] opacity-10 animate-pulse" />

      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="max-w-4xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-[#88ff00]/30 bg-[#88ff00]/5 text-[#88ff00] text-xs font-bold uppercase tracking-widest mb-8">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#88ff00] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#88ff00]"></span>
            </span>
            VUSUAL Revenue Engineering
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black leading-[1.1] tracking-tighter mb-8 uppercase">
            We Build <span className="neon-text">Monolithic</span> <br /> 
            Digital Presence.
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-400 mb-12 max-w-2xl leading-relaxed">
            Combining the technical precision of data science with high-luxury visual design to accelerate your revenue from zero to exit.
          </p>

          <div className="flex flex-col sm:flex-row gap-6">
            <button 
              onClick={onStartAudit}
              className="px-10 py-5 rounded-full bg-white text-black font-black text-lg hover:bg-[#88ff00] transition-all transform hover:scale-105 flex items-center justify-center gap-3 shadow-[0_0_40px_rgba(255,255,255,0.2)]"
            >
              Start Your Free Audit
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
            </button>
            <button className="px-10 py-5 rounded-full glass-panel border border-white/10 font-bold text-lg hover:bg-white/5 transition-all">
              Watch VUSUAL Case Study
            </button>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-2 md:grid-cols-4 gap-8 border-t border-white/5 pt-12">
          {[
            { label: 'ROAS Average', val: '4.8x' },
            { label: 'Keywords Ranked', val: '12k+' },
            { label: 'Audit Accuracy', val: '99%' },
            { label: 'Client Retention', val: '94%' },
          ].map((stat, i) => (
            <div key={i}>
              <div className="text-3xl font-black mb-1">{stat.val}</div>
              <div className="text-gray-500 text-sm font-bold uppercase tracking-wide">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
