
import React, { useState, useEffect } from 'react';
import { generateMarketingVisual, editImage, generateVideo, findCreativeReferences } from '../services/geminiService';

const AIStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'image' | 'video'>('image');
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [loading, setLoading] = useState(false);
  const [isResearching, setIsResearching] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [references, setReferences] = useState<{ title: string; uri: string }[]>([]);
  const [editPrompt, setEditPrompt] = useState('');
  const [hasKey, setHasKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      const selected = await (window as any).aistudio.hasSelectedApiKey();
      setHasKey(selected);
    };
    checkKey();
  }, []);

  const handleOpenKeySelection = async () => {
    await (window as any).aistudio.openSelectKey();
    setHasKey(true); // Assume success as per guidelines
  };

  const handleResearch = async () => {
    if (!prompt.trim()) return;
    setIsResearching(true);
    setReferences([]);
    try {
      const refs = await findCreativeReferences(prompt);
      setReferences(refs);
    } catch (err) {
      console.error("Research grounding failed:", err);
    } finally {
      setIsResearching(false);
    }
  };

  const handleGenerateImage = async () => {
    if (!hasKey) {
      await handleOpenKeySelection();
    }
    setLoading(true);
    try {
      const img = await generateMarketingVisual(prompt, size);
      setResult(img);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setHasKey(false);
        alert("API Key session expired. Please re-select your key.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEditImage = async () => {
    if (!result) return;
    setLoading(true);
    try {
      const img = await editImage(result, editPrompt);
      setResult(img);
      setEditPrompt('');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateVideo = async () => {
    if (!hasKey) {
      await handleOpenKeySelection();
    }
    setLoading(true);
    try {
      const vid = await generateVideo(prompt);
      setResult(vid);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("Requested entity was not found")) {
        setHasKey(false);
        alert("API Key session expired. Please re-select your key.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="py-24 px-6 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h2 className="text-5xl font-black mb-4 tracking-tighter">CREATIVE <span className="neon-text">FORGE</span></h2>
        <p className="text-gray-400 text-lg">AI-powered asset production grounded in real-world market aesthetics.</p>
      </div>

      {!hasKey && (
        <div className="mb-12 glass-panel p-8 rounded-3xl border-[#88ff00]/20 bg-[#88ff00]/5 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-xl font-bold mb-2">Advanced Models Require Authentication</h4>
            <p className="text-gray-400 text-sm">To use Veo Video and Pro Image models, please select a paid API key from your project.</p>
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-xs text-[#88ff00] underline mt-2 block">Learn about billing</a>
          </div>
          <button 
            onClick={handleOpenKeySelection}
            className="px-8 py-4 rounded-xl bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-colors"
          >
            Authorize Access
          </button>
        </div>
      )}

      <div className="flex justify-center mb-12">
        <div className="bg-white/5 p-1.5 rounded-2xl flex gap-1 border border-white/5">
          {['image', 'video'].map((tab) => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab as any); setResult(null); setReferences([]); }}
              className={`px-8 py-3 rounded-xl font-bold uppercase tracking-widest text-xs transition-all ${activeTab === tab ? 'bg-white text-black shadow-lg' : 'text-gray-500 hover:text-white'}`}
            >
              {tab} GEN
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div className="glass-panel p-8 md:p-12 rounded-[40px] border border-white/10">
            <div className="space-y-8">
              <div>
                <label className="block text-xs font-black uppercase tracking-[0.3em] text-gray-500 mb-4">Strategic Description</label>
                <textarea 
                  rows={4}
                  placeholder={activeTab === 'image' ? "A luxury high-end cinematic close up of a product..." : "Cinematic drone traversal through a cyber-organic landscape..."}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-lg focus:outline-none focus:border-[#88ff00] transition-all resize-none placeholder:text-gray-700"
                />
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={handleResearch}
                  disabled={isResearching || !prompt}
                  className="flex-1 py-4 rounded-xl border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white/5 transition-all flex items-center justify-center gap-2"
                >
                  {isResearching ? (
                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                  ) : (
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                  )}
                  Search Grounding References
                </button>
              </div>

              {activeTab === 'image' && (
                <div>
                  <label className="block text-xs font-black uppercase tracking-[0.3em] text-gray-500 mb-4">Output Fidelity</label>
                  <div className="grid grid-cols-3 gap-4">
                    {(['1K', '2K', '4K'] as const).map((s) => (
                      <button
                        key={s}
                        onClick={() => setSize(s)}
                        className={`py-4 rounded-xl border font-bold transition-all text-xs tracking-widest ${size === s ? 'border-[#88ff00] bg-[#88ff00]/10 text-[#88ff00]' : 'border-white/10 text-gray-500 hover:border-white/30'}`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <button 
                onClick={activeTab === 'image' ? handleGenerateImage : handleGenerateVideo}
                disabled={loading || !prompt}
                className="w-full py-6 rounded-2xl neon-gradient text-black font-black text-xl hover:scale-[1.01] disabled:opacity-20 transition-all flex items-center justify-center gap-4"
              >
                {loading ? (
                  <>
                    <div className="w-6 h-6 border-[3px] border-black border-t-transparent rounded-full animate-spin" />
                    PROCESSING ASSET...
                  </>
                ) : (
                  `INITIATE ${activeTab.toUpperCase()} SEQUENCE`
                )}
              </button>
            </div>
          </div>

          {/* References Grounding Display */}
          {(references.length > 0 || isResearching) && (
            <div className="glass-panel p-8 rounded-[40px] border border-white/5 animate-in fade-in slide-in-from-top-4 duration-500">
               <div className="flex items-center gap-2 mb-6">
                 <svg className="w-4 h-4 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 <span className="text-[10px] font-black uppercase tracking-widest text-[#88ff00]">Neural Grounding Data</span>
               </div>
               <div className="space-y-4">
                  {isResearching ? (
                    <div className="space-y-3">
                      <div className="h-4 w-full bg-white/5 animate-pulse rounded" />
                      <div className="h-4 w-3/4 bg-white/5 animate-pulse rounded" />
                    </div>
                  ) : (
                    references.map((ref, idx) => (
                      <a 
                        key={idx} 
                        href={ref.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/5 hover:border-[#88ff00]/40 transition-all group"
                      >
                         <span className="text-xs font-bold text-gray-400 group-hover:text-white transition-colors truncate pr-4">{ref.title}</span>
                         <svg className="w-4 h-4 text-gray-700 group-hover:text-[#88ff00] transition-colors flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                      </a>
                    ))
                  )}
               </div>
            </div>
          )}
        </div>

        <div className="glass-panel rounded-[40px] overflow-hidden flex flex-col min-h-[550px] border border-white/10 relative group neural-canvas shadow-2xl">
          {loading && <div className="scanning-bar" />}
          
          {!result ? (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-600 p-12 text-center relative overflow-hidden bg-black/40 backdrop-blur-sm">
              <div className="mesh-blob bg-[#88ff00] -top-20 -left-20" />
              <div className="mesh-blob bg-[#9d00ff] -bottom-20 -right-20" style={{ animationDelay: '-10s', animationDuration: '25s' }} />
              
              <div className="relative z-10 flex flex-col items-center">
                <div className="w-24 h-24 border-2 border-dashed border-gray-800 rounded-3xl mb-8 flex items-center justify-center animate-pulse">
                  <svg className="w-10 h-10 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </div>
                <p className="font-black uppercase tracking-[0.3em] text-xs opacity-40">Ready for Neural Rendering</p>
                {loading && <p className="mt-4 text-[10px] font-black uppercase tracking-widest text-[#88ff00] animate-pulse">Syncing with Creative Cloud...</p>}
              </div>
            </div>
          ) : activeTab === 'image' ? (
            <>
              <img src={result} alt="Generated Asset" className="flex-1 object-cover w-full h-full animate-in zoom-in-95 duration-1000" />
              <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col justify-end p-10">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Neural Edit Instruction</label>
                    <input 
                      type="text"
                      placeholder="e.g. 'Add volumetric lighting', 'Change sky to dusk'..."
                      value={editPrompt}
                      onChange={(e) => setEditPrompt(e.target.value)}
                      className="w-full bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl p-5 text-white focus:outline-none focus:border-[#88ff00] transition-all"
                    />
                  </div>
                  <button 
                    onClick={handleEditImage}
                    disabled={loading || !editPrompt}
                    className="w-full py-4 bg-[#88ff00] text-black font-black rounded-xl uppercase tracking-widest text-xs hover:scale-[1.02] transition-all"
                  >
                    Apply Refinement
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col">
              <video src={result} controls autoPlay loop className="flex-1 object-cover w-full h-full" />
              <div className="p-4 bg-black/40 border-t border-white/10 flex justify-between items-center">
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Veo Render Complete</span>
                <a href={result} download="vdm-asset.mp4" className="text-xs text-[#88ff00] hover:underline font-bold">Download Asset</a>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AIStudio;
