
import React, { useState, useMemo } from 'react';

const ROICalculator: React.FC = () => {
  const [params, setParams] = useState({
    budget: 5000,
    conversionRate: 2,
    dealValue: 1500,
    currentTraffic: 10000
  });

  const calculations = useMemo(() => {
    const estimatedNewTraffic = params.currentTraffic * 1.5; // VDM projected increase
    const currentRevenue = (params.currentTraffic * (params.conversionRate / 100)) * params.dealValue;
    const projectedRevenue = (estimatedNewTraffic * ((params.conversionRate + 1) / 100)) * params.dealValue;
    const netGrowth = projectedRevenue - currentRevenue;
    const roi = (netGrowth / params.budget) * 100;

    return {
      currentRevenue,
      projectedRevenue,
      netGrowth,
      roi: roi.toFixed(0)
    };
  }, [params]);

  const handleUnlockGrowth = () => {
    // Navigation would ideally be via PageState, but as this is a modular component 
    // it triggers the global state indirectly via window events or context.
    // For this build, we rely on the parent component handling state.
    const auditSection = document.getElementById('audit-section');
    if (auditSection) {
       auditSection.scrollIntoView({ behavior: 'smooth' });
    } else {
       // Manual dispatch for PageState.AUDIT if embedded in App.tsx
       window.dispatchEvent(new CustomEvent('vdm_navigate', { detail: 'AUDIT' }));
    }
  };

  return (
    <section className="py-24 px-6 max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 relative overflow-hidden">
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-[#88ff00]/5 rounded-full blur-[140px] pointer-events-none" />
      <div>
        <h2 className="text-5xl font-black mb-8 uppercase tracking-tighter">Revenue <br /><span className="neon-text">Multiplication</span></h2>
        <p className="text-gray-400 text-lg mb-12 leading-relaxed max-w-md">
          Stop guessing. Use our scientific model to project exactly how much growth we can unlock for your business by optimizing the funnel.
        </p>

        <div className="space-y-8 glass-panel p-10 rounded-[40px] border border-white/5">
          {[
            { label: 'Monthly Marketing Budget', key: 'budget', min: 1000, max: 50000, step: 500, prefix: '$' },
            { label: 'Current Conversion Rate (%)', key: 'conversionRate', min: 0.1, max: 10, step: 0.1, suffix: '%' },
            { label: 'Average Deal Value', key: 'dealValue', min: 10, max: 10000, step: 50, prefix: '$' },
            { label: 'Monthly Visitors', key: 'currentTraffic', min: 500, max: 100000, step: 500 },
          ].map((field) => (
            <div key={field.key}>
              <div className="flex justify-between mb-4">
                <label className="font-bold text-xs uppercase text-gray-500 tracking-widest">{field.label}</label>
                <span className="text-white font-black text-sm">
                  {field.prefix}{params[field.key as keyof typeof params].toLocaleString()}{field.suffix}
                </span>
              </div>
              <input 
                type="range"
                min={field.min}
                max={field.max}
                step={field.step}
                value={params[field.key as keyof typeof params]}
                onChange={(e) => setParams({ ...params, [field.key]: parseFloat(e.target.value) })}
                className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#88ff00]"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="glass-panel p-12 rounded-[50px] flex flex-col justify-between border-t border-r border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-8xl font-black uppercase -rotate-12 pointer-events-none">ROI</div>
        <div>
          <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-[#88ff00] mb-8">Projected Annual Impact</h4>
          <div className="space-y-12">
            <div>
              <div className="text-7xl font-black mb-2 tracking-tighter">${(calculations.netGrowth * 12).toLocaleString()}</div>
              <div className="text-gray-500 uppercase font-black text-xs tracking-widest">Additional Yearly Revenue</div>
            </div>
            <div>
              <div className="text-6xl font-black mb-2 text-[#9d00ff] tracking-tighter">{calculations.roi}%</div>
              <div className="text-gray-500 uppercase font-black text-xs tracking-widest">Projected Marketing ROI</div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-12 border-t border-white/5 space-y-6">
          <div className="flex justify-between text-xs uppercase font-bold tracking-widest">
            <span className="text-gray-500">Current Yearly Est.</span>
            <span className="text-white">${(calculations.currentRevenue * 12).toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-xs uppercase font-bold tracking-widest">
            <span className="text-gray-500">Optimized Yearly Est.</span>
            <span className="text-[#88ff00]">${(calculations.projectedRevenue * 12).toLocaleString()}</span>
          </div>
          <button 
            onClick={handleUnlockGrowth}
            className="w-full py-6 rounded-2xl neon-gradient text-black font-black uppercase text-sm tracking-[0.3em] mt-8 shadow-xl shadow-[#88ff00]/20 hover:scale-[1.02] transition-all transform active:scale-95"
          >
            Unlock This Growth Protocol
          </button>
        </div>
      </div>
    </section>
  );
};

export default ROICalculator;
