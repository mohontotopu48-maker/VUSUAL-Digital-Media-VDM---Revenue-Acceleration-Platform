
import React, { useState } from 'react';
import { User } from '../types';
import { Logo } from './Navbar';

interface ClientLoginProps {
  onLoginSuccess: (user: User) => void;
}

const ClientLogin: React.FC<ClientLoginProps> = ({ onLoginSuccess }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const handleInitialLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setStep(2);
      setLoading(false);
    }, 1500);
  };

  const handleVerify2FA = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      onLoginSuccess({
        id: 'cl_9812',
        name: 'Enterprise Alpha',
        email: email,
        role: 'CLIENT',
        token: 'vdm_tkn_client_mock'
      });
      setLoading(false);
    }, 1800);
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value !== '' && index < 5) {
      const nextInput = document.getElementById(`cl-otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center px-6 bg-[#050505] relative overflow-hidden">
      {/* Decorative luxury elements */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-[#88ff00]/5 rounded-full blur-[160px] -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-white/[0.02] rounded-full blur-[120px] translate-y-1/2 -translate-x-1/2" />

      <div className="glass-panel max-w-md w-full p-12 md:p-16 rounded-[48px] border-white/10 relative z-10 shadow-2xl">
        {loading && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-20 flex flex-col items-center justify-center rounded-[48px]">
            <div className="w-12 h-12 border-2 border-[#88ff00] border-t-transparent rounded-full animate-spin mb-6" />
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#88ff00] animate-pulse">
              Authenticating Vault Access...
            </p>
          </div>
        )}
        
        <div className="text-center mb-12">
          <Logo className="w-14 h-14 mx-auto mb-8 transition-transform duration-500 hover:scale-110" />
          <h2 className="text-2xl font-black uppercase tracking-tight mb-2">Prestige Access</h2>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.3em]">Revenue Monitoring Nexus</p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleInitialLogin} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Corporate Email</label>
              <input 
                type="email" 
                placeholder="CLIENT@ENTERPRISE.COM" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-5 text-sm font-bold focus:outline-none focus:border-[#88ff00] transition-colors placeholder:text-gray-700"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Vault Key</label>
              <input 
                type="password" 
                placeholder="••••••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-5 text-sm font-bold focus:outline-none focus:border-[#88ff00] transition-colors"
                required
              />
            </div>
            <button 
              type="submit"
              className="w-full py-5 rounded-2xl bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-all transform hover:scale-[1.01] shadow-xl shadow-white/5"
            >
              Request Access
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify2FA} className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
            <div className="text-center">
              <p className="text-xs text-gray-500 mb-8 font-medium">For your security, please enter the 6-digit verification code sent to your registered device.</p>
              <div className="flex justify-between gap-2">
                {otp.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`cl-otp-${idx}`}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(idx, e.target.value)}
                    className="w-12 h-16 bg-white/5 border border-white/10 rounded-2xl text-center text-2xl font-black focus:border-[#88ff00] focus:outline-none transition-all shadow-lg"
                  />
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <button 
                type="submit"
                disabled={otp.some(d => d === '')}
                className="w-full py-5 rounded-2xl bg-[#88ff00] text-black font-black uppercase text-xs tracking-widest hover:brightness-110 transition-all transform hover:scale-[1.01] shadow-xl shadow-[#88ff00]/20 disabled:opacity-30"
              >
                Unlock Dashboard
              </button>
              <button 
                type="button"
                onClick={() => setStep(1)}
                className="text-[9px] font-black text-gray-700 hover:text-white uppercase tracking-widest transition-colors"
              >
                Back to Login
              </button>
            </div>
          </form>
        )}
        
        <div className="mt-12 text-center">
           <p className="text-[9px] text-gray-800 uppercase tracking-widest font-black">Powered by VUSUAL Neural Security™</p>
        </div>
      </div>
    </section>
  );
};

export default ClientLogin;
