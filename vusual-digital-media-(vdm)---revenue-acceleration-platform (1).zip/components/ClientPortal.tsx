
import React, { useState, useEffect } from 'react';
import { User, Client } from '../types';
import { db } from '../services/dbService';

interface ClientPortalProps {
  user: User | null;
  onLogout: () => void;
}

const ClientPortal: React.FC<ClientPortalProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'campaigns' | 'vault'>('overview');
  const [clientData, setClientData] = useState<Client | null>(null);
  const [isDownloading, setIsDownloading] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      // Find client record by domain name matching the email domain or a hard-coded lookup
      const matchingClient = db.getClients().find(c => 
        c.name.toLowerCase().includes(user.name.toLowerCase()) || 
        user.email.toLowerCase().includes(c.domain.toLowerCase())
      ) || db.getClients()[0]; 
      
      setClientData(matchingClient);
    }
  }, [user]);

  const handleDownload = (docTitle: string) => {
    setIsDownloading(docTitle);
    setTimeout(() => {
       setIsDownloading(null);
       alert(`SECURE DOWNLOAD COMPLETE: ${docTitle}`);
    }, 2000);
  };

  if (!user || !clientData) return null;

  const dashboardStats = [
    { label: 'Attributed Revenue', val: clientData.arr, trend: '+14.2%', icon: '💰' },
    { label: 'Market Position', val: clientData.status, trend: 'OPTIMAL', icon: '📈' },
    { label: 'Ad Performance', val: '5.2x ROAS', trend: '+0.4', icon: '🎯' },
    { label: 'System Health', val: '98%', trend: 'SYNCED', icon: '⚡' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 animate-in fade-in duration-1000">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-16 border-b border-white/5 pb-10">
        <div>
          <div className="flex items-center gap-3 mb-2">
             <div className="w-2.5 h-2.5 rounded-full bg-[#88ff00] animate-pulse shadow-[0_0_10px_#88ff00]" />
             <span className="text-[10px] font-black uppercase tracking-[0.4em] text-[#88ff00]">High-Fidelity Nexus Connected</span>
          </div>
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-2">Prestige Portal: <span className="neon-text">{clientData.name}</span></h1>
          <p className="text-gray-500 text-xs uppercase tracking-[0.3em] font-bold">Managed by {clientData.owner} // Root Auth: {clientData.domain}</p>
        </div>
        <div className="flex gap-3 p-2 bg-white/5 rounded-2xl border border-white/5 backdrop-blur-xl">
          {['overview', 'campaigns', 'vault'].map((tab) => (
            <button key={tab} onClick={() => setActiveTab(tab as any)}
              className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-white text-black shadow-2xl' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}
            >
              {tab}
            </button>
          ))}
          <button onClick={onLogout} className="px-8 py-3 text-[10px] font-black uppercase tracking-widest text-red-500 hover:bg-red-500/10 rounded-xl transition-all">Sign Out</button>
        </div>
      </div>

      {activeTab === 'overview' && (
        <div className="space-y-12 animate-in fade-in duration-700">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {dashboardStats.map((stat, i) => (
              <div key={i} className="glass-panel p-10 rounded-[40px] border border-white/5 hover:border-[#88ff00]/20 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity text-6xl pointer-events-none">{stat.icon}</div>
                <div className="flex justify-between items-start mb-8">
                  <span className={`text-[9px] font-black px-4 py-1.5 rounded-full bg-white/5 uppercase tracking-widest ${stat.trend.startsWith('+') ? 'text-[#88ff00]' : 'text-blue-400'}`}>
                    {stat.trend}
                  </span>
                </div>
                <div className="text-4xl font-black mb-2 tracking-tighter group-hover:scale-105 transition-transform origin-left text-white">{stat.val}</div>
                <div className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 glass-panel p-12 rounded-[60px] border border-white/5 relative overflow-hidden bg-white/[0.01]">
              <div className="absolute inset-0 bg-grid opacity-5 pointer-events-none" />
              <div className="flex justify-between items-center mb-12 relative z-10">
                 <h3 className="text-2xl font-black uppercase tracking-tight">Active Strategy Clusters</h3>
                 <span className="text-[10px] font-black uppercase text-gray-600 tracking-widest">Live Optimization Engine</span>
              </div>
              <div className="space-y-12 relative z-10">
                {clientData.activeServices.map((service, i) => (
                  <div key={i} className="space-y-6">
                    <div className="flex justify-between items-end">
                      <div>
                        <div className="text-sm font-black uppercase tracking-widest text-white">{service} Protocol</div>
                        <div className="text-[9px] font-black text-gray-600 uppercase tracking-[0.4em] mt-1.5">Velocity Target: {80 + (i * 5)}% Cap</div>
                      </div>
                      <div className="flex items-center gap-2">
                         <div className="w-1.5 h-1.5 rounded-full bg-[#88ff00] animate-pulse" />
                         <div className="text-[10px] font-black text-[#88ff00] uppercase tracking-widest">Active Sync</div>
                      </div>
                    </div>
                    <div className="h-2.5 w-full bg-white/5 rounded-full overflow-hidden shadow-inner border border-white/5">
                      <div className="h-full bg-gradient-to-r from-[#88ff00] to-[#9d00ff] animate-pulse shadow-[0_0_15px_rgba(136,255,0,0.4)]" style={{ width: `${80 + (i * 5)}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-panel p-12 rounded-[60px] border border-white/5 flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-[0.02] text-8xl font-black rotate-12 pointer-events-none uppercase">LEDGER</div>
                <div className="relative z-10">
                  <h3 className="text-2xl font-black mb-10 uppercase tracking-tight">Financial Status</h3>
                  <div className="space-y-8">
                    <div className="p-8 rounded-[32px] bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
                       <div className="text-[10px] font-black uppercase text-gray-500 mb-2.5 tracking-widest">Billing Cycle Status</div>
                       <div className={`text-3xl font-black tracking-tighter ${clientData.billingStatus === 'Paid' ? 'text-[#88ff00]' : 'text-red-500'}`}>
                          {clientData.billingStatus.toUpperCase()}
                       </div>
                    </div>
                    <div className="p-8 rounded-[32px] bg-white/5 border border-white/5 hover:border-white/10 transition-colors">
                       <div className="text-[10px] font-black uppercase text-gray-500 mb-2.5 tracking-widest">Active Agreement</div>
                       <div className="text-2xl font-black text-white tracking-tighter uppercase">{clientData.agreementStatus}</div>
                    </div>
                  </div>
                </div>
                <button className="w-full py-6 rounded-3xl bg-white text-black font-black uppercase text-xs tracking-[0.3em] mt-10 hover:bg-[#88ff00] transition-all transform active:scale-95 shadow-xl shadow-white/5 relative z-10">Request Account Sync</button>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'vault' && (
        <div className="animate-in fade-in duration-700">
           <div className="flex justify-between items-end mb-12">
              <h3 className="text-3xl font-black uppercase tracking-tighter">Secure Document Vault</h3>
              <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">256-Bit Neural Encryption Active</span>
           </div>
           <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { title: `Master Agreement - ${clientData.name}`, type: 'Legal PDF', size: '2.4MB' },
                { title: 'Neural Market Audit Q4', type: 'Strategy', size: '14.8MB' },
                { title: 'Proprietary Keyword Matrix', type: 'Intelligence', size: '1.2MB' },
              ].map((doc, i) => (
                <div key={i} className="glass-panel p-12 rounded-[48px] border border-white/5 hover:border-[#88ff00]/40 transition-all cursor-pointer group relative overflow-hidden">
                   <div className="absolute top-0 right-0 p-8 opacity-[0.02] text-8xl font-black uppercase group-hover:scale-110 transition-transform pointer-events-none">DOC</div>
                   <div className="w-20 h-20 rounded-3xl bg-white/5 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform mb-10 border border-white/5 shadow-inner">📂</div>
                   <h4 className="text-xl font-black uppercase tracking-tight mb-4 text-white group-hover:text-[#88ff00] transition-colors relative z-10">{doc.title}</h4>
                   <div className="flex justify-between items-center text-[10px] font-black text-gray-600 uppercase tracking-[0.2em] mb-10 relative z-10">
                     <span>{doc.type}</span>
                     <span>{doc.size}</span>
                   </div>
                   <button 
                    onClick={() => handleDownload(doc.title)}
                    disabled={!!isDownloading}
                    className="w-full py-4 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all flex items-center justify-center gap-3 relative z-10"
                  >
                     {isDownloading === doc.title ? (
                       <>
                         <div className="w-3 h-3 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                         DOWNLOADING...
                       </>
                     ) : (
                       <>
                         <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                         SECURE DOWNLOAD
                       </>
                     )}
                   </button>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
};

export default ClientPortal;
