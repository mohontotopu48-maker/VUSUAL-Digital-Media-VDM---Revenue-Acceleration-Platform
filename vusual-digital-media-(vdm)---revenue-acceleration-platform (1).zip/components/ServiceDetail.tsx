
import React, { useEffect, useRef, useState } from 'react';
import { ServiceData } from '../types';

const mockServiceData: Record<string, ServiceData> = {
  'national-seo': {
    id: 'national-seo',
    name: 'National SEO Strategy',
    category: 'SEO',
    heroHeadline: 'Command the Digital Landscape at Scale.',
    heroSubheadline: 'Dominate competitive national keywords and build a revenue engine that scales with your ambition.',
    painPoints: [
      { title: 'The Plateau Effect', desc: 'Your rankings have stalled. You need enterprise-grade technical SEO to break through the noise.' },
      { title: 'Content Decay', desc: 'Your old content is losing value. We revitalize your library for maximum search longevity.' },
      { title: 'High CAC', desc: 'Paid acquisition is getting too expensive. Organic traffic lowers your average customer cost.' }
    ],
    pricingTier: [
      { name: 'Core Strategy', price: '$5,000', features: ['Full Technical Audit', 'Topic Cluster Development', '10 Enterprise Backlinks', 'Weekly Performance Sync'] },
      { name: 'National Scale', price: '$10,000', features: ['Content Production Engine', 'PR & Link Building', 'Market Share Analysis', 'Priority Tech Support'] },
      { name: 'Enterprise Power', price: '$20,000+', features: ['Custom Roadmap', 'Full Integration with Internal Teams', 'AI Content Optimization', 'Global Reach Expansion'] }
    ],
    techProof: {
      toolName: 'VisualPulse™ Revenue Tracker',
      desc: 'Our neural network analyzes trillions of search data points to predict algorithm shifts before they happen.',
      stats: ['Predictive Analytics', 'ROAS Centric Reporting', 'Automated Content Gaps']
    },
    faqs: [
      { q: 'What is National SEO Strategy?', a: 'National SEO focuses on ranking for broad, high-volume keywords across an entire country, targeting top-of-funnel awareness and authoritative domain positioning.' }
    ],
    methodology: [
      { step: 1, name: 'Technical Core Audit', desc: 'Identifying crawl budget inefficiencies and schema gaps.' },
      { step: 2, name: 'Topic Cluster Mapping', desc: 'Creating semantically connected content silos.' },
      { step: 3, name: 'Backlink Infrastructure', desc: 'Acquiring high-DA tier-1 links through proprietary PR engines.' }
    ]
  },
  'ghl-management': {
    id: 'ghl-management',
    name: 'GoHighLevel Nexus Ecosystems',
    category: 'INFRASTRUCTURE',
    heroHeadline: 'Your CRM Is Not A Tool. It\'s A Revenue Hub.',
    heroSubheadline: 'We engineer high-fidelity GoHighLevel instances that automate the entire buyer journey from first touch to closed-won.',
    painPoints: [
      { title: 'Lead Leakage', desc: 'Leads are falling through cracks of manual follow-up. We build automated safety nets that capture 100% of intent.' },
      { title: 'Tech Stack Chaos', desc: 'Consolidate 10 apps into one powerful VDM-optimized GoHighLevel instance for total operational clarity.' },
      { title: 'Silent Databases', desc: 'Turn your stagnant contact list into a conversational revenue stream through behavioral workflows and AI nurturing.' }
    ],
    pricingTier: [
      { name: 'Nexus Core', price: '$2,500', features: ['CRM Migration', 'Standard Funnel Build', 'Email/SMS Automation', 'Monthly Optimization'] },
      { name: 'Growth Engine', price: '$5,000', features: ['Custom UI Overlays', 'Advanced AI Booking Bots', 'Integrated Ad Tracking', 'Multi-channel Workflows'] },
      { name: 'Monolith Enterprise', price: '$9,000+', features: ['Full White-Label Setup', 'Custom API Integrations', 'Bi-weekly Strategy Uplinks', 'Priority 24/7 Support'] }
    ],
    techProof: {
      toolName: 'NexusFlow™ Snapshots',
      desc: 'Our proprietary GHL Snapshots come pre-loaded with over 5 years of conversion testing data and luxury UI assets.',
      stats: ['Sub-1s Lead Response', '40% Higher Booking Rate', 'Zero-Waste Automation']
    },
    faqs: [
      { q: 'Can you migrate my existing Salesforce/Hubspot data?', a: 'Yes. We specialize in zero-loss data migrations into high-performance VDM-engineered GHL environments.' }
    ],
    methodology: [
      { step: 1, name: 'Operational Audit', desc: 'Mapping your current sales friction points and leakage vectors.' },
      { step: 2, name: 'Nexus Implementation', desc: 'Deploying the VDM infrastructure into your GHL instance.' },
      { step: 3, name: 'Velocity Testing', desc: 'Stress-testing automated sequences for maximum psychological conversion.' }
    ]
  },
  'google-ads': {
    id: 'google-ads',
    name: 'Algorithmic Search Ads',
    category: 'PAID MEDIA',
    heroHeadline: 'Eliminate Waste. Harvest Revenue.',
    heroSubheadline: 'Precision media buying that prioritizes bottom-line ROAS through algorithmic bidding and high-intent keyword harvesting.',
    painPoints: [
      { title: 'Budget Hemorrhaging', desc: 'Stop spending on clicks that don\'t convert. Our exclusion-first strategy stops the bleed immediately.' },
      { title: 'Low Quality Score', desc: 'High CPCs are killing your margins. We optimize landers and ad copy to slash your costs.' },
      { title: 'Attribution Chaos', desc: 'Not knowing where your sales come from is dangerous. We install absolute tracking clarity.' }
    ],
    pricingTier: [
      { name: 'Precision Start', price: '$3,500', features: ['Search & Remarketing', 'Keyword Research', 'Ad Copy Sprints', 'Performance Dashboard'] },
      { name: 'ROAS Maximizer', price: '$6,500', features: ['Dynamic Search Ads', 'A/B Testing', 'Competitor Conquesting', 'Call Tracking'] },
      { name: 'Global Dominance', price: '$12,000+', features: ['Performance Max Mastery', 'YouTube Video Ads', 'Cross-Channel attribution', 'Dedicated Media Buyer'] }
    ],
    techProof: {
      toolName: 'BidSurgical™ AI',
      desc: 'Our proprietary script suite manages bids at the micro-second level, reacting to competitor budget fluctuations instantly.',
      stats: ['-30% Avg. CPC Reduction', '+45% Conversion Lift', 'Zero-Waste Exclusion Engine']
    },
    faqs: [
      { q: 'Is Google Ads still effective in the AI era?', a: 'More than ever. AI tools allow us to find patterns in user intent that were previously invisible, allowing for hyper-efficient bidding.' }
    ],
    methodology: [
      { step: 1, name: 'Audit & Exclusion', desc: 'Eliminating non-performing keyword waste from historical data.' },
      { step: 2, name: 'Funnel Alignment', desc: 'Matching ad copy to searcher intent with surgical precision.' },
      { step: 3, name: 'Scaling Protocol', desc: 'Pushing budget into winning segments while maintaining target CPA.' }
    ]
  },
  'local-seo': {
    id: 'local-seo',
    name: 'Local SEO Dominance',
    category: 'SEO',
    heroHeadline: 'Own Your Local Market With Surgical Precision.',
    heroSubheadline: 'We don\'t just put you on the map. We make you the only choice for local high-intent buyers.',
    painPoints: [
      { title: 'The Invisible Business', desc: 'You\'re ranking for keywords, but your local competitors are stealing high-intent traffic from the Map Pack.' },
      { title: 'Inconsistent Lead Flow', desc: 'One day you\'re busy, the next you\'re silent. Our automation ensures a steady stream of leads.' },
      { title: 'Review Sabotage', desc: 'Lack of reviews are killing your conversion before a customer even clicks your site.' }
    ],
    pricingTier: [
      { name: 'Silver Accelerator', price: '$2,500', features: ['Google Business Profile Optimization', 'Local Citation Cleanup', 'Monthly Reporting', '5 Target Keywords'] },
      { name: 'Gold Growth', price: '$4,500', features: ['All Silver Features', 'Localized Content Strategy', 'Review Automation Tool', '15 Target Keywords', 'Dedicated Strategist'] },
      { name: 'Platinum Elite', price: '$8,000', features: ['All Gold Features', 'Multi-location Management', 'Hyper-local PPC Sync', 'Custom Data Dashboard', '24/7 Priority Support'] }
    ],
    techProof: {
      toolName: 'MapPulse™ Intelligence',
      desc: 'Our proprietary tool tracks real-time grid rankings across your service area, allowing us to pivot strategies based on neighborhood competition.',
      stats: ['99% Tracking Accuracy', 'Real-time Lead Origin Data', 'Automated Competitor Drift Detection']
    },
    faqs: [
      { q: 'Why does Local SEO matter in 2025?', a: 'Over 46% of all Google searches have local intent. If you aren\'t in the top 3 of the Map Pack, you are invisible to half your market.' }
    ],
    methodology: [
      { step: 1, name: 'Local Asset Ingestion', desc: 'Syncing your Google Business Profile with our proprietary ranking grid.' },
      { step: 2, name: 'Proximity Engineering', desc: 'Deploying neighborhood-specific landing pages and hyper-local citations.' },
      { step: 3, name: 'Review Velocity Sync', desc: 'Automating the acquisition of high-fidelity social proof to dominate the 3-pack.' }
    ]
  }
};

const useScrollReveal = (threshold = 0.15) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setIsVisible(true); observer.unobserve(entry.target); }
    }, { threshold, rootMargin: '0px 0px -10% 0px' });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return [ref, isVisible] as const;
};

const RevealSection: React.FC<{ children: React.ReactNode; className?: string; id?: string; delay?: number; scale?: boolean }> = ({ 
  children, className = "", id, delay = 0, scale = false 
}) => {
  const [ref, isVisible] = useScrollReveal();
  return (
    <section 
      ref={ref as any} id={id}
      style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] scroll-mt-24 ${isVisible ? 'opacity-100 translate-y-0 scale-100' : `opacity-0 translate-y-16 ${scale ? 'scale-95' : ''}`} ${className}`}
    >
      {children}
    </section>
  );
};

const ServiceDetail: React.FC<{ serviceId: string; onGetAudit: () => void; onViewPricing: () => void }> = ({ serviceId, onGetAudit, onViewPricing }) => {
  const data = mockServiceData[serviceId] || mockServiceData['national-seo'];
  const [activeSection, setActiveSection] = useState('hero');

  const tocItems = [
    { id: 'hero', label: 'Performance Hub' },
    { id: 'pain-points', label: 'Gap Analysis' },
    { id: 'methodology', label: 'VDM Protocol' },
    { id: 'pricing', label: 'Tiered Scaling' },
    { id: 'tech-proof', label: 'Proprietary Stack' },
    { id: 'faq', label: 'Intelligence FAQ' },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) setActiveSection(entry.target.id); });
    }, { rootMargin: '-20% 0px -60% 0px' });
    tocItems.forEach(item => { const el = document.getElementById(item.id); if (el) observer.observe(el); });
    return () => observer.disconnect();
  }, [data]);

  return (
    <div className="pb-32 relative">
      <aside className="hidden xl:block fixed right-12 top-1/2 -translate-y-1/2 z-40">
        <div className="glass-panel p-8 rounded-[32px] border-white/5 w-64">
           <div className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 mb-8">Navigation Protocol</div>
           <div className="space-y-1">
              {tocItems.map((item) => (
                <button key={item.id} onClick={() => document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' })} className={`group relative flex items-center w-full pl-6 py-3 text-left transition-all ${activeSection === item.id ? 'text-[#88ff00]' : 'text-gray-500 hover:text-white'}`}>
                  <div className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 transition-all ${activeSection === item.id ? 'h-6 bg-[#88ff00]' : 'h-0'}`} />
                  <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                </button>
              ))}
           </div>
        </div>
      </aside>

      <RevealSection id="hero" className="pt-20 pb-32 border-b border-white/5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center relative">
          <div className="absolute top-0 -left-20 w-64 h-64 bg-[#88ff00]/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="relative z-10">
            <div className="inline-block px-4 py-1 rounded-full border border-[#88ff00]/30 bg-[#88ff00]/5 text-[#88ff00] text-[10px] font-black uppercase tracking-widest mb-8">{data.category} // PERFORMANCE CHANNEL</div>
            <h1 className="text-6xl md:text-8xl font-black leading-[1.05] tracking-tighter mb-8 uppercase">{data.heroHeadline}</h1>
            <p className="text-xl text-gray-400 mb-12 max-w-lg leading-relaxed">{data.heroSubheadline}</p>
            <div className="flex gap-4">
              <button onClick={onGetAudit} className="px-8 py-4 rounded-full bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-all shadow-xl shadow-white/5">Get Your Audit</button>
              <button onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })} className="px-8 py-4 rounded-full glass-panel border border-white/10 font-bold uppercase text-xs tracking-widest">View Pricing</button>
            </div>
          </div>
          <div className="glass-panel w-full aspect-square rounded-[40px] border-white/20 p-12 flex items-center justify-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#88ff00]/5 to-[#9d00ff]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            <div className="text-8xl opacity-10 font-black rotate-12 uppercase group-hover:scale-110 transition-transform duration-[2000ms]">{data.category}</div>
            <div className="absolute bottom-10 left-10 text-[8px] font-black text-gray-600 uppercase tracking-widest">VUSUAL_MEDIA_NODE_CONNECTED</div>
          </div>
        </div>
      </RevealSection>

      <RevealSection id="pain-points" className="py-32 px-6 max-w-7xl mx-auto" scale>
        <h2 className="text-sm font-black uppercase tracking-[0.4em] text-gray-600 mb-20 text-center">Market Inefficiencies // We Solve Them</h2>
        <div className="grid md:grid-cols-3 gap-10">
          {data.painPoints.map((p, i) => (
            <div key={i} className="glass-panel p-10 rounded-3xl border border-white/5 hover:border-[#88ff00]/30 transition-all group">
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-500 mb-8 group-hover:text-[#88ff00] transition-colors">0{i+1}</div>
              <h3 className="text-xl font-bold mb-4 uppercase tracking-tighter">{p.title}</h3>
              <p className="text-gray-500 leading-relaxed text-sm">{p.desc}</p>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="methodology" className="py-32 px-6 max-w-7xl mx-auto">
        <h2 className="text-center text-4xl md:text-6xl font-black mb-20 uppercase tracking-tighter">VDM Monolithic Protocol</h2>
        <div className="space-y-16">
          {data.methodology?.map((step, i) => (
            <div key={i} className="flex flex-col md:flex-row items-center gap-12 group">
              <div className="w-16 h-16 rounded-2xl bg-black border border-white/10 flex items-center justify-center text-[#88ff00] font-black text-xl group-hover:bg-[#88ff00] group-hover:text-black transition-all">{step.step}</div>
              <div className="flex-1">
                <h3 className="text-2xl font-black uppercase mb-4 tracking-tight">{step.name}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="pricing" className="py-32 px-6 max-w-7xl mx-auto border-y border-white/5" scale>
        <div className="text-center mb-20">
           <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Tiered Scaling</h2>
           <p className="text-gray-500 text-sm font-bold uppercase tracking-widest">Select the operational velocity that fits your revenue targets.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {data.pricingTier.map((tier, i) => (
            <div key={i} className={`glass-panel p-12 rounded-[40px] border transition-all ${i === 1 ? 'scale-105 border-[#88ff00]/40 z-10' : 'border-white/10'}`}>
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-gray-500">{tier.name}</h4>
                <div className="text-5xl font-black mb-10 tracking-tighter">{tier.price}<span className="text-sm text-gray-600 font-bold"> /mo</span></div>
                <ul className="space-y-6 mb-12">
                  {tier.features.map((f, j) => (<li key={j} className="text-sm text-gray-400 flex gap-4"><svg className="w-5 h-5 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>{f}</li>))}
                </ul>
                <button onClick={onGetAudit} className={`w-full py-5 rounded-2xl font-black uppercase text-xs tracking-widest ${i === 1 ? 'neon-gradient text-black shadow-lg shadow-[#88ff00]/20' : 'bg-white/5 text-white'}`}>Select Tier</button>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="tech-proof" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="glass-panel p-20 rounded-[60px] border border-white/10 grid lg:grid-cols-2 gap-20 items-center bg-white/[0.01]">
            <div>
               <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#88ff00] mb-8">Proprietary Technology Stack</h4>
               <h2 className="text-5xl font-black mb-10 tracking-tighter uppercase leading-[1.1]">{data.techProof.toolName}</h2>
               <p className="text-xl text-gray-400 mb-12 leading-relaxed">{data.techProof.desc}</p>
               <div className="space-y-6">
                  {data.techProof.stats.map((stat, i) => (<div key={i} className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest text-white/80"><div className="w-6 h-6 rounded bg-[#88ff00]/10 flex items-center justify-center"><svg className="w-4 h-4 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg></div>{stat}</div>))}
               </div>
            </div>
            <div className="w-full aspect-square glass-panel rounded-[40px] border border-white/20 p-8 flex items-center justify-center bg-[#050505] relative overflow-hidden">
                <div className="absolute inset-0 bg-grid opacity-10" />
                <div className="text-6xl font-black text-white/5 uppercase select-none relative z-10">VDM CORE</div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#88ff00]/5 rounded-full blur-[60px] animate-pulse" />
            </div>
        </div>
      </RevealSection>

      <RevealSection id="faq" className="py-32 px-6 max-w-3xl mx-auto border-t border-white/5">
        <h2 className="text-center text-4xl font-black mb-20 tracking-tighter uppercase">Market Intelligence FAQ</h2>
        <div className="space-y-16">
          {data.faqs.map((faq, i) => (
            <div key={i} className="group">
              <h3 className="text-xl font-bold mb-6 group-hover:text-[#88ff00] uppercase tracking-tight transition-colors">{faq.q}</h3>
              <p className="text-gray-500 leading-relaxed italic border-l-2 border-white/5 pl-6 group-hover:border-[#88ff00]/50 transition-all">{faq.a}</p>
            </div>
          ))}
        </div>
      </RevealSection>
    </div>
  );
};

export default ServiceDetail;
