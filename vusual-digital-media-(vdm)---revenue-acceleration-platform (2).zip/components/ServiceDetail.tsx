
import React, { useEffect, useRef, useState } from 'react';
import { ServiceData } from '../types';

const mockServiceData: Record<string, ServiceData> = {
  'national-seo': {
    id: 'national-seo',
    name: 'National SEO Strategy',
    category: 'SEO',
    heroHeadline: 'Command the Digital Landscape at Scale.',
    heroSubheadline: 'Dominate competitive national keywords and build a revenue engine that scales with your ambition.',
    painPoints: [
      { title: 'The Plateau Effect', desc: 'Your rankings have stalled. You need enterprise-grade technical SEO to break through the noise.' },
      { title: 'Content Decay', desc: 'Your old content is losing value. We revitalize your library for maximum search longevity.' },
      { title: 'High CAC', desc: 'Paid acquisition is getting too expensive. Organic traffic lowers your average customer cost.' }
    ],
    pricingTier: [
      { name: 'Core Strategy', price: '$5,000', features: ['Full Technical Audit', 'Topic Cluster Development', '10 Enterprise Backlinks', 'Weekly Performance Sync'] },
      { name: 'National Scale', price: '$10,000', features: ['Content Production Engine', 'PR & Link Building', 'Market Share Analysis', 'Priority Tech Support'] },
      { name: 'Enterprise Power', price: '$20,000+', features: ['Custom Roadmap', 'Full Integration with Internal Teams', 'AI Content Optimization', 'Global Reach Expansion'] }
    ],
    techProof: {
      toolName: 'VisualPulse™ Revenue Tracker',
      desc: 'Our neural network analyzes trillions of search data points to predict algorithm shifts before they happen.',
      stats: ['Predictive Analytics', 'ROAS Centric Reporting', 'Automated Content Gaps']
    },
    faqs: [
      { q: 'What is National SEO Strategy?', a: 'National SEO focuses on ranking for broad, high-volume keywords across an entire country, targeting top-of-funnel awareness and authoritative domain positioning.' }
    ],
    methodology: [
      { step: 1, name: 'Technical Core Audit', desc: 'Identifying crawl budget inefficiencies and schema gaps.' },
      { step: 2, name: 'Topic Cluster Mapping', desc: 'Creating semantically connected content silos.' },
      { step: 3, name: 'Backlink Infrastructure', desc: 'Acquiring high-DA tier-1 links through proprietary PR engines.' }
    ]
  },
  'ghl-management': {
    id: 'ghl-management',
    name: 'GoHighLevel Nexus Ecosystems',
    category: 'INFRASTRUCTURE',
    heroHeadline: 'Your CRM Is Not A Tool. It\'s A Revenue Hub.',
    heroSubheadline: 'We engineer high-fidelity GoHighLevel instances that automate the entire buyer journey from first touch to closed-won.',
    painPoints: [
      { title: 'Lead Leakage', desc: 'Leads are falling through cracks of manual follow-up. We build automated safety nets that capture 100% of intent.' },
      { title: 'Tech Stack Chaos', desc: 'Consolidate 10 apps into one powerful VDM-optimized GoHighLevel instance for total operational clarity.' },
      { title: 'Silent Databases', desc: 'Turn your stagnant contact list into a conversational revenue stream through behavioral workflows and AI nurturing.' }
    ],
    pricingTier: [
      { name: 'Nexus Core', price: '$2,500', features: ['CRM Migration', 'Standard Funnel Build', 'Email/SMS Automation', 'Monthly Optimization'] },
      { name: 'Growth Engine', price: '$3,500', features: ['Custom UI Overlays', 'Advanced AI Booking Bots', 'Integrated Ad Tracking', 'Multi-channel Workflows'] },
      { name: 'Monolith Enterprise', price: '$9,000+', features: ['Full White-Label Setup', 'Custom API Integrations', 'Bi-weekly Strategy Uplinks', 'Priority 24/7 Support'] }
    ],
    techProof: {
      toolName: 'NexusFlow™ Snapshots',
      desc: 'Our proprietary GHL Snapshots come pre-loaded with over 5 years of conversion testing data and luxury UI assets.',
      stats: ['Sub-1s Lead Response', '40% Higher Booking Rate', 'Zero-Waste Automation']
    },
    faqs: [
      { q: 'Can you migrate my existing Salesforce/Hubspot data?', a: 'Yes. We specialize in zero-loss data migrations into high-performance VDM-engineered GHL environments.' }
    ],
    methodology: [
      { step: 1, name: 'Operational Audit', desc: 'Mapping your current sales friction points and leakage vectors.' },
      { step: 2, name: 'Nexus Implementation', desc: 'Deploying the VDM infrastructure into your GHL instance.' },
      { step: 3, name: 'Velocity Testing', desc: 'Stress-testing automated sequences for maximum psychological conversion.' }
    ]
  },
  'google-ads': {
    id: 'google-ads',
    name: 'Algorithmic Search Ads',
    category: 'PAID MEDIA',
    heroHeadline: 'Eliminate Waste. Harvest Revenue.',
    heroSubheadline: 'Precision media buying that prioritizes bottom-line ROAS through algorithmic bidding and high-intent keyword harvesting.',
    painPoints: [
      { title: 'Budget Hemorrhaging', desc: 'Stop spending on clicks that don\'t convert. Our exclusion-first strategy stops the bleed immediately.' },
      { title: 'Low Quality Score', desc: 'High CPCs are killing your margins. We optimize landers and ad copy to slash your costs.' },
      { title: 'Attribution Chaos', desc: 'Not knowing where your sales come from is dangerous. We install absolute tracking clarity.' }
    ],
    pricingTier: [
      { name: 'Precision Start', price: '$3,500', features: ['Search & Remarketing', 'Keyword Research', 'Ad Copy Sprints', 'Performance Dashboard'] },
      { name: 'ROAS Maximizer', price: '$6,500', features: ['Dynamic Search Ads', 'A/B Testing', 'Competitor Conquesting', 'Call Tracking'] },
      { name: 'Global Dominance', price: '$12,000+', features: ['Performance Max Mastery', 'YouTube Video Ads', 'Cross-Channel attribution', 'Dedicated Media Buyer'] }
    ],
    techProof: {
      toolName: 'BidSurgical™ AI',
      desc: 'Our proprietary script suite manages bids at the micro-second level, reacting to competitor budget fluctuations instantly.',
      stats: ['-30% Avg. CPC Reduction', '+45% Conversion Lift', 'Zero-Waste Exclusion Engine']
    },
    faqs: [
      { q: 'Is Google Ads still effective in the AI era?', a: 'More than ever. AI tools allow us to find patterns in user intent that were previously invisible, allowing for hyper-efficient bidding.' }
    ],
    methodology: [
      { step: 1, name: 'Audit & Exclusion', desc: 'Eliminating non-performing keyword waste from historical data.' },
      { step: 2, name: 'Funnel Alignment', desc: 'Matching ad copy to searcher intent with surgical precision.' },
      { step: 3, name: 'Scaling Protocol', desc: 'Pushing budget into winning segments while maintaining target CPA.' }
    ]
  },
  'paid-social': {
    id: 'paid-social',
    name: 'Paid Social Mastery',
    category: 'PAID MEDIA',
    heroHeadline: 'Surgical Social Acquisition.',
    heroSubheadline: 'Mastering Meta, LinkedIn, and TikTok algorithms to harvest high-intent customers at the lowest possible CAC.',
    painPoints: [
      { title: 'Algorithm Fatigue', desc: 'Your creative is burning out and CPMs are rising. We use AI-driven content velocity to maintain performance.' },
      { title: 'Low Lead Quality', desc: 'Generating volume is easy; generating revenue is hard. Our pixel strategy prioritizes bottom-funnel conversion.' },
      { title: 'Attribution Blindness', desc: 'IOS14+ destroyed standard tracking. Our server-side CAPI integration restores data clarity.' }
    ],
    pricingTier: [
      { name: 'Growth Tier', price: '$3,500', features: ['Meta Ad Management', 'Static Creative Suite', 'Weekly ROAS Audits', 'Standard Pixel Setup'] },
      { name: 'Scaling Master', price: '$7,000', features: ['Multi-Channel (Meta + LI)', 'Video Motion Assets', 'Retargeting Architecture', 'Server-Side CAPI'] },
      { name: 'Alpha Performance', price: '$12,000+', features: ['Full Global Omni-Channel', 'Influencer White-listing', 'Dynamic Creative Optimization', 'Custom Dashboard'] }
    ],
    techProof: {
      toolName: 'SocialGraph™ Attribution',
      desc: 'Our server-to-server tracking engine ensures 100% of conversion data is attributed to the correct creative lever.',
      stats: ['98% Attribution Clarity', 'Real-time Creative Score', 'Automated Bidding Logic']
    },
    faqs: [
      { q: 'Which platform is best for B2B?', a: 'LinkedIn remains the authority for high-ticket B2B, but Meta often provides lower-cost lead volume when paired with the right exclusion filters.' }
    ],
    methodology: [
      { step: 1, name: 'Creative Audit', desc: 'Analyzing past asset performance to find visual winners.' },
      { step: 2, name: 'Funnel Architecture', desc: 'Building cold, warm, and hot audience buckets with specific triggers.' },
      { step: 3, name: 'CAPI Implementation', desc: 'Establishing server-side tracking to bypass browser limitations.' }
    ]
  },
  'social-media-management': {
    id: 'social-media-management',
    name: 'Prestige Social Management',
    category: 'BRAND',
    heroHeadline: 'Command Social Authority.',
    heroSubheadline: 'High-fidelity community management for elite brands who value prestige over vanity metrics.',
    painPoints: [
      { title: 'Visual Mediocrity', desc: 'Low-quality posts hurt your high-ticket credibility. We deliver 4K visual prestige daily.' },
      { title: 'Zero Engagement', desc: 'Broadcast-only social is dead. We build actual dialogue with your industry leaders.' },
      { title: 'Algorithm Blindness', desc: 'Stop guessing. We use data-driven hooks to guarantee organic reach expansion.' }
    ],
    pricingTier: [
      { name: 'Brand Aura', price: '$2,000', features: ['3 High-Fid Posts/Week', 'Luxury Graphic Design', 'Basic Community Management', 'Monthly Report'] },
      { name: 'Market Authority', price: '$4,500', features: ['Daily Content Engine', 'Short-form Video Edits', 'Active Prospecting', 'Weekly Performance Sync'] },
      { name: 'Global Prestige', price: '$9,000+', features: ['Omni-channel Dominance', 'Influencer Outreach', 'Personal Brand Management', 'Custom Photography'] }
    ],
    techProof: {
      toolName: 'VibeCheck™ Analytics',
      desc: 'Our sentiment analysis engine monitors brand perception in real-time, allowing for rapid strategy pivots.',
      stats: ['94% Sentiment Accuracy', '+300% Engagement Lift', 'Top 1% Visual Standard']
    },
    faqs: [
      { q: 'Do you handle TikTok and Reels?', a: 'Yes. Our short-form video engine is designed specifically for high-conversion vertical content and cinematic hooks.' }
    ],
    methodology: [
      { step: 1, name: 'Visual Synthesis', desc: 'Defining your brand\'s unique aesthetic fingerprint.' },
      { step: 2, name: 'Content Sprints', desc: 'Rapid deployment of high-fidelity creative clusters.' },
      { step: 3, name: 'Authority Amplification', desc: 'Leveraging organic trending hooks to scale reach.' }
    ]
  },
  'custom-design': {
    id: 'custom-design',
    name: 'Prestige Visual Design',
    category: 'BRAND',
    heroHeadline: 'Visual Fidelity. Human Conversion.',
    heroSubheadline: 'We build high-ticket UI/UX environments that convert cold traffic into loyal advocates through luxury aesthetics.',
    painPoints: [
      { title: 'Template Mediocrity', desc: 'Your site looks like everyone else\'s. We create bespoke digital experiences that demand attention.' },
      { title: 'Friction Points', desc: 'Users are getting lost in your navigation. Our user-centric flow eliminates every barrier to conversion.' },
      { title: 'Performance Drag', desc: 'Heavy visuals are slowing your site. We deliver 4K aesthetics with sub-second response times.' }
    ],
    pricingTier: [
      { name: 'Visual Uplift', price: '$8,000', features: ['Core UI/UX Redesign', 'Brand Identity Refinement', 'Responsive Asset Suite', 'Interactive Prototyping'] },
      { name: 'Experience Master', price: '$15,000', features: ['Full Custom Development', 'Motion Graphics Integration', 'Conversion Science Audit', 'Multi-Step Forms'] },
      { name: 'Brand Monolith', price: '$30,000+', features: ['Omni-channel Visual System', 'Custom Video Production', 'Post-Launch Velocity CRO', 'Priority Support'] }
    ],
    techProof: {
      toolName: 'EyeTrack™ Simulation',
      desc: 'Our design process includes AI-driven eye-tracking heatmaps to ensure your most important CTAs receive primary focus.',
      stats: ['+22% Avg. CTR Increase', 'Sub-500ms Page Loads', '99.9% UX Satisfaction']
    },
    faqs: [
      { q: 'Why invest in custom design?', a: 'For high-ticket services, visual trust is everything. A template screams "budget", whereas custom design screams "authority".' }
    ],
    methodology: [
      { step: 1, name: 'Archetype Discovery', desc: 'Defining the psychological profile of your ideal high-value customer.' },
      { step: 2, name: 'Visual Sprint', desc: 'Creating high-fidelity mockups that push industry boundaries.' },
      { step: 3, name: 'Conversion Test', desc: 'Optimizing interaction points for maximum psychological momentum.' }
    ]
  }
};

const useScrollReveal = (threshold = 0.15) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setIsVisible(true); observer.unobserve(entry.target); }
    }, { threshold, rootMargin: '0px 0px -10% 0px' });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);
  return [ref, isVisible] as const;
};

const RevealSection: React.FC<{ children: React.ReactNode; className?: string; id?: string; delay?: number; scale?: boolean }> = ({ 
  children, className = "", id, delay = 0, scale = false 
}) => {
  const [ref, isVisible] = useScrollReveal();
  return (
    <section 
      ref={ref as any} id={id}
      style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-[1200ms] ease-[cubic-bezier(0.16,1,0.3,1)] scroll-mt-24 ${isVisible ? 'opacity-100 translate-y-0 scale-100' : `opacity-0 translate-y-16 ${scale ? 'scale-95' : ''}`} ${className}`}
    >
      {children}
    </section>
  );
};

const ServiceDetail: React.FC<{ serviceId: string; onGetAudit: () => void; onViewPricing: () => void }> = ({ serviceId, onGetAudit, onViewPricing }) => {
  const data = mockServiceData[serviceId] || mockServiceData['national-seo'];
  const [activeSection, setActiveSection] = useState('hero');

  const tocItems = [
    { id: 'hero', label: 'Performance Hub' },
    { id: 'pain-points', label: 'Gap Analysis' },
    { id: 'methodology', label: 'VDM Protocol' },
    { id: 'pricing', label: 'Tiered Scaling' },
    { id: 'tech-proof', label: 'Proprietary Stack' },
    { id: 'faq', label: 'Intelligence FAQ' },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if (entry.isIntersecting) setActiveSection(entry.target.id); });
    }, { rootMargin: '-20% 0px -60% 0px' });
    tocItems.forEach(item => { const el = document.getElementById(item.id); if (el) observer.observe(el); });
    return () => observer.disconnect();
  }, [data]);

  return (
    <div className="pb-32 relative">
      <aside className="hidden xl:block fixed right-12 top-1/2 -translate-y-1/2 z-40">
        <div className="glass-panel p-8 rounded-[32px] border-white/5 w-64">
           <div className="text-[10px] font-black uppercase tracking-[0.4em] text-gray-500 mb-8">Navigation Protocol</div>
           <div className="space-y-1">
              {tocItems.map((item) => (
                <button key={item.id} onClick={() => document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' })} className={`group relative flex items-center w-full pl-6 py-3 text-left transition-all ${activeSection === item.id ? 'text-[#88ff00]' : 'text-gray-500 hover:text-white'}`}>
                  <div className={`absolute left-0 top-1/2 -translate-y-1/2 w-1 transition-all ${activeSection === item.id ? 'h-6 bg-[#88ff00]' : 'h-0'}`} />
                  <span className="text-[10px] font-black uppercase tracking-widest">{item.label}</span>
                </button>
              ))}
           </div>
        </div>
      </aside>

      <RevealSection id="hero" className="pt-20 pb-32 border-b border-white/5 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-20 items-center relative">
          <div className="absolute top-0 -left-20 w-64 h-64 bg-[#88ff00]/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="relative z-10">
            <div className="inline-block px-4 py-1 rounded-full border border-[#88ff00]/30 bg-[#88ff00]/5 text-[#88ff00] text-[10px] font-black uppercase tracking-widest mb-8">{data.category} // PERFORMANCE CHANNEL</div>
            <h1 className="text-6xl md:text-8xl font-black leading-[1.05] tracking-tighter mb-8 uppercase">{data.heroHeadline}</h1>
            <p className="text-xl text-gray-400 mb-12 max-w-lg leading-relaxed">{data.heroSubheadline}</p>
            <div className="flex gap-4">
              <button onClick={onGetAudit} className="px-8 py-4 rounded-full bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#88ff00] transition-all shadow-xl shadow-white/5">Get Your Audit</button>
              <button onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })} className="px-8 py-4 rounded-full glass-panel border border-white/10 font-bold uppercase text-xs tracking-widest">View Pricing</button>
            </div>
          </div>
          <div className="glass-panel w-full aspect-square rounded-[40px] border-white/20 p-12 flex items-center justify-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#88ff00]/5 to-[#9d00ff]/5 opacity-0 group-hover:opacity-100 transition-opacity duration-1000" />
            <div className="text-8xl opacity-10 font-black rotate-12 uppercase group-hover:scale-110 transition-transform duration-[2000ms]">{data.category}</div>
            <div className="absolute bottom-10 left-10 text-[8px] font-black text-gray-600 uppercase tracking-widest">VUSUAL_MEDIA_NODE_CONNECTED</div>
          </div>
        </div>
      </RevealSection>

      <RevealSection id="pain-points" className="py-32 px-6 max-w-7xl mx-auto" scale>
        <h2 className="text-sm font-black uppercase tracking-[0.4em] text-gray-600 mb-20 text-center">Market Inefficiencies // We Solve Them</h2>
        <div className="grid md:grid-cols-3 gap-10">
          {data.painPoints.map((p, i) => (
            <div key={i} className="glass-panel p-10 rounded-3xl border border-white/5 hover:border-[#88ff00]/30 transition-all group">
              <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-gray-500 mb-8 group-hover:text-[#88ff00] transition-colors">0{i+1}</div>
              <h3 className="text-xl font-bold mb-4 uppercase tracking-tighter">{p.title}</h3>
              <p className="text-gray-500 leading-relaxed text-sm">{p.desc}</p>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="methodology" className="py-32 px-6 max-w-7xl mx-auto">
        <h2 className="text-center text-4xl md:text-6xl font-black mb-20 uppercase tracking-tighter">VDM Monolithic Protocol</h2>
        <div className="space-y-16">
          {data.methodology?.map((step, i) => (
            <div key={i} className="flex flex-col md:flex-row items-center gap-12 group">
              <div className="w-16 h-16 rounded-2xl bg-black border border-white/10 flex items-center justify-center text-[#88ff00] font-black text-xl group-hover:bg-[#88ff00] group-hover:text-black transition-all">{step.step}</div>
              <div className="flex-1">
                <h3 className="text-2xl font-black uppercase mb-4 tracking-tight">{step.name}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="pricing" className="py-32 px-6 max-w-7xl mx-auto border-y border-white/5" scale>
        <div className="text-center mb-20">
           <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">Tiered Scaling</h2>
           <p className="text-gray-500 text-sm font-bold uppercase tracking-widest">Select the operational velocity that fits your revenue targets.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {data.pricingTier.map((tier, i) => (
            <div key={i} className={`glass-panel p-12 rounded-[40px] border transition-all ${i === 1 ? 'scale-105 border-[#88ff00]/40 z-10' : 'border-white/10'}`}>
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] mb-8 text-gray-500">{tier.name}</h4>
                <div className="text-5xl font-black mb-10 tracking-tighter">{tier.price}<span className="text-sm text-gray-600 font-bold"> /mo</span></div>
                <ul className="space-y-6 mb-12">
                  {tier.features.map((f, j) => (<li key={j} className="text-sm text-gray-400 flex gap-4"><svg className="w-5 h-5 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>{f}</li>))}
                </ul>
                <button onClick={onGetAudit} className={`w-full py-5 rounded-2xl font-black uppercase text-xs tracking-widest ${i === 1 ? 'neon-gradient text-black shadow-lg shadow-[#88ff00]/20' : 'bg-white/5 text-white'}`}>Select Tier</button>
            </div>
          ))}
        </div>
      </RevealSection>

      <RevealSection id="tech-proof" className="py-32 px-6 max-w-7xl mx-auto">
        <div className="glass-panel p-20 rounded-[60px] border border-white/10 grid lg:grid-cols-2 gap-20 items-center bg-white/[0.01]">
            <div>
               <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-[#88ff00] mb-8">Proprietary Technology Stack</h4>
               <h2 className="text-5xl font-black mb-10 tracking-tighter uppercase leading-[1.1]">{data.techProof.toolName}</h2>
               <p className="text-xl text-gray-400 mb-12 leading-relaxed">{data.techProof.desc}</p>
               <div className="space-y-6">
                  {data.techProof.stats.map((stat, i) => (<div key={i} className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest text-white/80"><div className="w-6 h-6 rounded bg-[#88ff00]/10 flex items-center justify-center"><svg className="w-4 h-4 text-[#88ff00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg></div>{stat}</div>))}
               </div>
            </div>
            <div className="w-full aspect-square glass-panel rounded-[40px] border border-white/20 p-8 flex items-center justify-center bg-[#050505] relative overflow-hidden">
                <div className="absolute inset-0 bg-grid opacity-10" />
                <div className="text-6xl font-black text-white/5 uppercase select-none relative z-10">VDM CORE</div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-[#88ff00]/5 rounded-full blur-[60px] animate-pulse" />
            </div>
        </div>
      </RevealSection>

      <RevealSection id="faq" className="py-32 px-6 max-w-3xl mx-auto border-t border-white/5">
        <h2 className="text-center text-4xl font-black mb-20 tracking-tighter uppercase">Market Intelligence FAQ</h2>
        <div className="space-y-16">
          {data.faqs.map((faq, i) => (
            <div key={i} className="group">
              <h3 className="text-xl font-bold mb-6 group-hover:text-[#88ff00] uppercase tracking-tight transition-colors">{faq.q}</h3>
              <p className="text-gray-500 leading-relaxed italic border-l-2 border-white/5 pl-6 group-hover:border-[#88ff00]/50 transition-all">{faq.a}</p>
            </div>
          ))}
        </div>
      </RevealSection>
    </div>
  );
};

export default ServiceDetail;
