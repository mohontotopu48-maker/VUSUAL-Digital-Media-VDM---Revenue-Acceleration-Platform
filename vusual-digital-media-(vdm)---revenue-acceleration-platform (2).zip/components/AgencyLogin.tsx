
import React, { useState } from 'react';
import { User } from '../types';
import { Logo } from './Navbar';

interface AgencyLoginProps {
  onLoginSuccess: (user: User) => void;
}

const AgencyLogin: React.FC<AgencyLoginProps> = ({ onLoginSuccess }) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);

  const handleInitialLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate API delay for credential verification
    setTimeout(() => {
      setStep(2);
      setLoading(false);
    }, 1800);
  };

  const handleVerify2FA = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate OTP verification
    setTimeout(() => {
      onLoginSuccess({
        id: 'ag_001',
        name: 'Chief Strategist',
        email: email,
        role: 'AGENCY',
        token: 'vdm_tkn_agency_master'
      });
      setLoading(false);
    }, 2000);
  };

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value !== '' && index < 5) {
      const nextInput = document.getElementById(`ag-otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center px-6 neural-canvas relative overflow-hidden">
      {/* Background Matrix-like elements */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="h-full w-full bg-[radial-gradient(#9d00ff_1px,transparent_1px)] [background-size:20px_20px]" />
      </div>

      <div className="glass-panel max-w-md w-full p-10 md:p-14 rounded-[40px] border border-[#9d00ff]/20 relative z-10 shadow-[0_0_80px_rgba(157,0,255,0.1)]">
        {loading && (
          <div className="absolute inset-0 bg-black/95 z-20 flex flex-col items-center justify-center text-center px-10 rounded-[40px]">
            <div className="w-16 h-16 border-4 border-[#9d00ff] border-t-transparent rounded-full animate-spin mb-8" />
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-[#9d00ff] animate-pulse">
              {step === 2 ? 'Verifying Neural Key...' : 'Syncing Command Identity...'}
            </p>
          </div>
        )}
        
        <div className="text-center mb-10">
          <Logo className="w-16 h-16 mx-auto mb-6 transition-transform duration-700 hover:rotate-12" />
          <h2 className="text-2xl font-black uppercase tracking-tight">Master Command</h2>
          <p className="text-[10px] text-[#9d00ff] font-black mt-2 uppercase tracking-[0.3em]">Protocol // Secure Gateway</p>
        </div>

        {step === 1 ? (
          <form onSubmit={handleInitialLogin} className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Strategist ID</label>
              <input 
                type="email" 
                placeholder="STRATEGIST@VUSUALDM.COM" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-xs font-bold tracking-widest focus:outline-none focus:border-[#9d00ff] transition-colors placeholder:text-gray-800"
                required
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-500">Master Key</label>
              <input 
                type="password" 
                placeholder="••••••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-xs font-bold tracking-widest focus:outline-none focus:border-[#9d00ff] transition-colors"
                required
              />
            </div>
            <button 
              type="submit"
              className="w-full py-5 rounded-xl bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#9d00ff] transition-all transform hover:scale-[1.02] shadow-lg shadow-white/5 active:scale-95"
            >
              Initialize Command
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify2FA} className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
            <div className="text-center">
              <p className="text-xs text-gray-400 mb-6 font-medium">Authentication required. Please enter the code from your security token.</p>
              <div className="flex justify-between gap-2">
                {otp.map((digit, idx) => (
                  <input
                    key={idx}
                    id={`ag-otp-${idx}`}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(idx, e.target.value)}
                    className="w-12 h-14 bg-white/5 border border-white/10 rounded-xl text-center text-xl font-black text-[#9d00ff] focus:border-[#9d00ff] focus:outline-none transition-all shadow-inner"
                  />
                ))}
              </div>
            </div>
            <div className="flex flex-col gap-4">
              <button 
                type="submit"
                disabled={otp.some(d => d === '')}
                className="w-full py-5 rounded-xl bg-[#9d00ff] text-white font-black uppercase text-xs tracking-widest hover:brightness-125 transition-all transform hover:scale-[1.02] shadow-lg shadow-[#9d00ff]/30 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                Establish Neural Link
              </button>
              <button 
                type="button"
                onClick={() => setStep(1)}
                className="text-[9px] font-black text-gray-700 hover:text-white uppercase tracking-widest transition-colors"
              >
                Back to Identity Verification
              </button>
            </div>
          </form>
        )}
        
        <div className="mt-10 pt-10 border-t border-white/5 flex items-center justify-between">
           <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
             <span className="text-[8px] font-black text-gray-700 uppercase tracking-widest">Master-Encrypt Active</span>
           </div>
           <span className="text-[8px] font-black text-gray-800 uppercase tracking-widest">REF: GATEWAY-MASTER-01</span>
        </div>
      </div>
    </section>
  );
};

export default AgencyLogin;
