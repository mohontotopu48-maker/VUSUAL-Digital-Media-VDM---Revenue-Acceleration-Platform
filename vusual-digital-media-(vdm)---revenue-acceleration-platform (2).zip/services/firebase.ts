
import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";

// Config values are now sourced from the environment for production-grade security
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY || "AIzaSyBycQudhY9bwVtLwHH1Ljb8hcp6XgiqfDE",
  authDomain: process.env.FIREBASE_AUTH_DOMAIN || "vusual-1446e.firebaseapp.com",
  projectId: process.env.FIREBASE_PROJECT_ID || "vusual-1446e",
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET || "vusual-1446e.firebasestorage.app",
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || "150547964141",
  appId: process.env.FIREBASE_APP_ID || "1:150547964141:web:a7e280c5c457906f73ece4",
  measurementId: process.env.FIREBASE_MEASUREMENT_ID || "G-6LN8YPSCE5"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Safe Analytics initialization using isSupported() to prevent SSR/Environment errors
export let analytics: any = null;

if (typeof window !== 'undefined') {
  isSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
    }
  }).catch((err) => {
    console.warn("Firebase Analytics initialization skipped:", err);
  });
}
